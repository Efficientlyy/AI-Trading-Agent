# API Key Management System Testing Strategy

## Overview

This document outlines a comprehensive testing strategy for the API Key Management System implementation. It provides detailed guidance on testing approaches, test cases, and validation procedures to ensure the system functions correctly and securely.

## Table of Contents

1. [Testing Objectives](#testing-objectives)
2. [Testing Levels](#testing-levels)
3. [Unit Testing](#unit-testing)
4. [Integration Testing](#integration-testing)
5. [End-to-End Testing](#end-to-end-testing)
6. [Security Testing](#security-testing)
7. [Performance Testing](#performance-testing)
8. [Test Automation](#test-automation)
9. [Test Environment Setup](#test-environment-setup)
10. [Test Data Management](#test-data-management)
11. [Test Execution Plan](#test-execution-plan)
12. [Defect Management](#defect-management)

## Testing Objectives

The primary objectives of testing the API Key Management System are:

1. **Functionality Verification**: Ensure all features work as specified
2. **Security Validation**: Verify that API keys are stored and transmitted securely
3. **Integration Confirmation**: Validate that existing components correctly use the API Key Manager
4. **Performance Assessment**: Ensure the system performs efficiently under expected load
5. **Usability Evaluation**: Verify that the admin interface is intuitive and functional

## Testing Levels

### Unit Testing

Unit tests focus on individual components in isolation, using mocks for dependencies.

### Integration Testing

Integration tests verify that components work together correctly.

### End-to-End Testing

End-to-end tests validate complete user workflows across the entire system.

### Security Testing

Security tests focus on identifying vulnerabilities and ensuring data protection.

### Performance Testing

Performance tests evaluate system behavior under various load conditions.

## Unit Testing

### API Key Manager Tests

#### Test Cases

1. **Test API Key Storage and Retrieval**
   - Set an API key and verify it can be retrieved
   - Verify non-existent keys return None
   - Test with various service and key name combinations

2. **Test API Key Deletion**
   - Delete a specific key and verify it's removed
   - Delete all keys for a service and verify they're removed
   - Attempt to delete non-existent keys and verify proper handling

3. **Test Service Listing**
   - Add keys for multiple services and verify they appear in the list
   - Verify service metadata is correctly included
   - Verify key values are not exposed in service listings

4. **Test Encryption**
   - Verify that saved data is encrypted
   - Verify that data can be decrypted with the correct key
   - Test with different secret keys to ensure isolation

#### Implementation Example

```python
# src/tests/common/security/test_api_key_manager.py
import pytest
import os
import tempfile
from src.common.security.api_key_manager import APIKeyManager

@pytest.fixture
def api_key_manager():
    # Create a temporary file for testing
    fd, path = tempfile.mkstemp()
    os.close(fd)
    
    # Create manager with test secret key
    manager = APIKeyManager(config_path=path, secret_key="test-secret-key")
    
    yield manager
    
    # Clean up
    if os.path.exists(path):
        os.unlink(path)

def test_set_get_api_key(api_key_manager):
    # Set a key
    assert api_key_manager.set_api_key("test", "api_key", "test-value")
    
    # Get the key
    assert api_key_manager.get_api_key("test", "api_key") == "test-value"
    
    # Get a non-existent key
    assert api_key_manager.get_api_key("test", "non_existent") is None
    assert api_key_manager.get_api_key("non_existent", "api_key") is None

def test_delete_api_key(api_key_manager):
    # Set keys
    api_key_manager.set_api_key("test", "api_key", "test-value")
    api_key_manager.set_api_key("test", "secret_key", "secret-value")
    
    # Delete one key
    assert api_key_manager.delete_api_key("test", "api_key")
    assert api_key_manager.get_api_key("test", "api_key") is None
    assert api_key_manager.get_api_key("test", "secret_key") == "secret-value"
    
    # Delete entire service
    assert api_key_manager.delete_api_key("test")
    assert api_key_manager.get_api_key("test", "secret_key") is None

def test_list_services(api_key_manager):
    # Set keys for multiple services
    api_key_manager.set_api_key("service1", "api_key", "value1")
    api_key_manager.set_api_key("service2", "api_key", "value2")
    
    # List services
    services = api_key_manager.list_services()
    assert len(services) == 2
    assert "service1" in services
    assert "service2" in services
    assert "api_key" in services["service1"]["keys"]
    assert services["service1"]["configured"] is True

def test_encryption(api_key_manager):
    # Set a key
    api_key_manager.set_api_key("test", "api_key", "test-value")
    
    # Check that the file exists and contains encrypted data
    with open(api_key_manager.config_path, 'r') as f:
        data = f.read()
        # Encrypted data should not contain the plain text value
        assert "test-value" not in data
        # Encrypted data should be a Fernet token (base64 encoded)
        assert data.startswith('gAAAAA')
    
    # Create a new manager with the same path and key
    new_manager = APIKeyManager(
        config_path=api_key_manager.config_path,
        secret_key="test-secret-key"
    )
    
    # Verify the key can be retrieved
    assert new_manager.get_api_key("test", "api_key") == "test-value"
    
    # Create a manager with a different key
    wrong_key_manager = APIKeyManager(
        config_path=api_key_manager.config_path,
        secret_key="wrong-secret-key"
    )
    
    # Verify decryption fails
    assert wrong_key_manager.api_keys == {}
```

### Service Validator Tests

#### Test Cases

1. **Test Twitter Validator**
   - Test with valid credentials
   - Test with invalid credentials
   - Test with missing credentials

2. **Test Binance Validator**
   - Test with valid credentials
   - Test with invalid credentials
   - Test with missing credentials

3. **Test NewsAPI Validator**
   - Test with valid credentials
   - Test with invalid credentials
   - Test with missing credentials

#### Implementation Example

```python
# src/tests/common/security/test_api_validators.py
import pytest
from unittest.mock import patch, MagicMock
from src.common.security.api_validators import (
    validate_twitter_keys,
    validate_binance_keys,
    validate_newsapi_keys,
    get_validator_for_service
)

@pytest.mark.asyncio
async def test_twitter_validator():
    # Mock the TwitterCollector
    with patch('src.common.security.api_validators.TwitterCollector') as MockTwitterCollector:
        # Set up the mock
        mock_instance = MockTwitterCollector.return_value
        mock_instance.initialize = MagicMock()
        
        # Test with valid credentials
        mock_instance.use_mock = False
        assert await validate_twitter_keys({
            "api_key": "valid-key",
            "api_secret": "valid-secret",
            "bearer_token": "valid-token"
        }) is True
        
        # Test with invalid credentials
        mock_instance.use_mock = True
        assert await validate_twitter_keys({
            "api_key": "invalid-key",
            "api_secret": "invalid-secret",
            "bearer_token": "invalid-token"
        }) is False
        
        # Test with missing credentials
        assert await validate_twitter_keys({}) is False

@pytest.mark.asyncio
async def test_binance_validator():
    # Mock the BinanceConnector
    with patch('src.common.security.api_validators.BinanceConnector') as MockBinanceConnector:
        # Set up the mock
        mock_instance = MockBinanceConnector.return_value
        mock_instance._init_rest_client = MagicMock()
        
        # Test with valid credentials
        mock_instance.fetch_available_symbols = MagicMock(return_value=["BTC/USDT", "ETH/USDT"])
        assert await validate_binance_keys({
            "api_key": "valid-key",
            "api_secret": "valid-secret"
        }) is True
        
        # Test with invalid credentials
        mock_instance.fetch_available_symbols = MagicMock(side_effect=Exception("Invalid API key"))
        assert await validate_binance_keys({
            "api_key": "invalid-key",
            "api_secret": "invalid-secret"
        }) is False
        
        # Test with missing credentials
        assert await validate_binance_keys({}) is False

@pytest.mark.asyncio
async def test_newsapi_validator():
    # Mock the NewsAPIClient
    with patch('src.common.security.api_validators.NewsAPIClient') as MockNewsAPIClient:
        # Set up the mock
        mock_instance = MockNewsAPIClient.return_value
        
        # Test with valid credentials
        mock_instance.get_top_headlines = MagicMock(return_value={"articles": []})
        assert await validate_newsapi_keys({
            "api_key": "valid-key"
        }) is True
        
        # Test with invalid credentials
        mock_instance.get_top_headlines = MagicMock(side_effect=Exception("Invalid API key"))
        assert await validate_newsapi_keys({
            "api_key": "invalid-key"
        }) is False
        
        # Test with missing credentials
        assert await validate_newsapi_keys({}) is False

def test_get_validator_for_service():
    # Test getting validators for known services
    assert get_validator_for_service("twitter") is validate_twitter_keys
    assert get_validator_for_service("binance") is validate_binance_keys
    assert get_validator_for_service("newsapi") is validate_newsapi_keys
    
    # Test getting validator for unknown service
    assert get_validator_for_service("unknown") is None
```

## Integration Testing

### API Endpoint Tests

#### Test Cases

1. **Test Service Listing Endpoint**
   - Test with no services configured
   - Test with multiple services configured
   - Test with authentication

2. **Test API Key Setting Endpoint**
   - Test setting a new key
   - Test updating an existing key
   - Test with invalid input
   - Test with authentication

3. **Test API Key Deletion Endpoint**
   - Test deleting a specific key
   - Test deleting all keys for a service
   - Test with non-existent keys
   - Test with authentication

4. **Test Service Connection Testing Endpoint**
   - Test with valid credentials
   - Test with invalid credentials
   - Test with non-existent validator
   - Test with authentication

#### Implementation Example

```python
# src/tests/api/routes/test_api_settings.py
import pytest
from fastapi.testclient import TestClient
from src.api.main import app
from src.common.security.api_key_manager import APIKeyManager
import tempfile
import os
from unittest.mock import patch

# Mock authentication for testing
app.dependency_overrides = {
    "src.common.security.auth.get_current_admin_user": lambda: {"username": "admin"}
}

@pytest.fixture
def client():
    # Create a temporary file for testing
    fd, path = tempfile.mkstemp()
    os.close(fd)
    
    # Override the API key manager with a test instance
    from src.api.routes.api_settings import api_key_manager
    test_manager = APIKeyManager(config_path=path, secret_key="test-secret-key")
    app.dependency_overrides["src.api.routes.api_settings.api_key_manager"] = lambda: test_manager
    
    client = TestClient(app)
    
    yield client
    
    # Clean up
    if os.path.exists(path):
        os.unlink(path)

def test_list_services_empty(client):
    response = client.get("/api/settings/services")
    assert response.status_code == 200
    assert response.json() == []

def test_list_services_with_data(client):
    # Set some keys
    client.post("/api/settings/keys", json={"service": "test1", "key_name": "api_key", "value": "value1"})
    client.post("/api/settings/keys", json={"service": "test2", "key_name": "api_key", "value": "value2"})
    
    # List services
    response = client.get("/api/settings/services")
    assert response.status_code == 200
    services = response.json()
    assert len(services) == 2
    assert services[0]["service"] in ["test1", "test2"]
    assert services[1]["service"] in ["test1", "test2"]
    assert services[0]["service"] != services[1]["service"]

def test_set_api_key(client):
    # Set a key
    response = client.post(
        "/api/settings/keys",
        json={"service": "test", "key_name": "api_key", "value": "test-value"}
    )
    assert response.status_code == 201
    
    # Check if the key was set
    response = client.get("/api/settings/services")
    assert response.status_code == 200
    services = response.json()
    assert len(services) == 1
    assert services[0]["service"] == "test"
    assert "api_key" in services[0]["keys"]

def test_update_api_key(client):
    # Set a key
    client.post(
        "/api/settings/keys",
        json={"service": "test", "key_name": "api_key", "value": "test-value"}
    )
    
    # Update the key
    response = client.post(
        "/api/settings/keys",
        json={"service": "test", "key_name": "api_key", "value": "updated-value"}
    )
    assert response.status_code == 201
    
    # Check if the key was updated
    # Note: We can't directly check the value for security reasons
    response = client.get("/api/settings/services")
    assert response.status_code == 200
    services = response.json()
    assert len(services) == 1
    assert services[0]["service"] == "test"
    assert "api_key" in services[0]["keys"]

def test_delete_api_key(client):
    # Set a key
    client.post(
        "/api/settings/keys",
        json={"service": "test", "key_name": "api_key", "value": "test-value"}
    )
    
    # Delete the key
    response = client.delete("/api/settings/keys/test/api_key")
    assert response.status_code == 200
    
    # Check if the key was deleted
    response = client.get("/api/settings/services")
    assert response.status_code == 200
    assert response.json() == []

def test_delete_service(client):
    # Set multiple keys for a service
    client.post(
        "/api/settings/keys",
        json={"service": "test", "key_name": "api_key", "value": "test-value"}
    )
    client.post(
        "/api/settings/keys",
        json={"service": "test", "key_name": "secret_key", "value": "secret-value"}
    )
    
    # Delete the service
    response = client.delete("/api/settings/services/test")
    assert response.status_code == 200
    
    # Check if all keys were deleted
    response = client.get("/api/settings/services")
    assert response.status_code == 200
    assert response.json() == []

def test_delete_nonexistent_key(client):
    response = client.delete("/api/settings/keys/nonexistent/api_key")
    assert response.status_code == 404

def test_test_service_connection(client):
    # Mock the validator
    with patch('src.common.security.api_validators.get_validator_for_service') as mock_get_validator:
        # Set up a mock validator that returns True
        async def mock_validator(keys):
            return True
        mock_get_validator.return_value = mock_validator
        
        # Set a key
        client.post(
            "/api/settings/keys",
            json={"service": "test", "key_name": "api_key", "value": "test-value"}
        )
        
        # Test the connection
        response = client.post("/api/settings/test/test")
        assert response.status_code == 200
        assert response.json()["success"] is True
        
        # Set up a mock validator that returns False
        async def mock_validator_fail(keys):
            return False
        mock_get_validator.return_value = mock_validator_fail
        
        # Test the connection
        response = client.post("/api/settings/test/test")
        assert response.status_code == 200
        assert response.json()["success"] is False
        
        # Test with non-existent validator
        mock_get_validator.return_value = None
        response = client.post("/api/settings/test/nonexistent")
        assert response.status_code == 400

def test_authentication_required(client):
    # Remove the authentication override
    app.dependency_overrides = {}
    
    # Try to access the endpoints without authentication
    response = client.get("/api/settings/services")
    assert response.status_code == 401 or response.status_code == 403
    
    response = client.post(
        "/api/settings/keys",
        json={"service": "test", "key_name": "api_key", "value": "test-value"}
    )
    assert response.status_code == 401 or response.status_code == 403
    
    # Restore the authentication override for other tests
    app.dependency_overrides = {
        "src.common.security.auth.get_current_admin_user": lambda: {"username": "admin"}
    }
```

### Component Integration Tests

#### Test Cases

1. **Test Twitter Collector Integration**
   - Verify the collector uses API keys from the manager
   - Test fallback to environment variables
   - Test fallback to config values

2. **Test News Collector Integration**
   - Verify the collector uses API keys from the manager
   - Test fallback to environment variables
   - Test fallback to config values

3. **Test Binance Connector Integration**
   - Verify the connector uses API keys from the manager
   - Test fallback to environment variables
   - Test fallback to config values

#### Implementation Example

```python
# src/tests/integration/test_component_integration.py
import pytest
import os
from unittest.mock import patch
from src.common.security.api_key_manager import APIKeyManager
import tempfile

@pytest.fixture
def api_key_manager():
    # Create a temporary file for testing
    fd, path = tempfile.mkstemp()
    os.close(fd)
    
    # Create manager with test secret key
    manager = APIKeyManager(config_path=path, secret_key="test-secret-key")
    
    yield manager
    
    # Clean up
    if os.path.exists(path):
        os.unlink(path)

@pytest.mark.asyncio
async def test_twitter_collector_integration(api_key_manager):
    # Set API keys in the manager
    api_key_manager.set_api_key("twitter", "api_key", "manager-api-key")
    api_key_manager.set_api_key("twitter", "api_secret", "manager-api-secret")
    api_key_manager.set_api_key("twitter", "bearer_token", "manager-bearer-token")
    
    # Override the global API key manager
    with patch('src.common.security.api_keys.get_api_key_manager', return_value=api_key_manager):
        # Import the collector
        from src.analysis_agents.early_detection.data_collectors.twitter_collector import TwitterCollector
        
        # Create a collector with no environment variables or config
        with patch.dict(os.environ, {}, clear=True):
            with patch('src.common.config.config.get', return_value=""):
                collector = TwitterCollector()
                
                # Verify it uses the API keys from the manager
                assert collector.api_key == "manager-api-key"
                assert collector.api_secret == "manager-api-secret"
                assert collector.bearer_token == "manager-bearer-token"
        
        # Test fallback to environment variables
        with patch.dict(os.environ, {
            "TWITTER_API_KEY": "env-api-key",
            "TWITTER_API_SECRET": "env-api-secret",
            "TWITTER_BEARER_TOKEN": "env-bearer-token"
        }):
            # Remove keys from manager
            api_key_manager.delete_api_key("twitter")
            
            # Create a new collector
            collector = TwitterCollector()
            
            # Verify it uses the environment variables
            assert collector.api_key == "env-api-key"
            assert collector.api_secret == "env-api-secret"
            assert collector.bearer_token == "env-bearer-token"
        
        # Test fallback to config values
        with patch.dict(os.environ, {}, clear=True):
            with patch('src.common.config.config.get', side_effect=lambda key, default: {
                "apis.twitter.api_key": "config-api-key",
                "apis.twitter.api_secret": "config-api-secret",
                "apis.twitter.bearer_token": "config-bearer-token"
            }.get(key, default)):
                collector = TwitterCollector()
                
                # Verify it uses the config values
                assert collector.api_key == "config-api-key"
                assert collector.api_secret == "config-api-secret"
                assert collector.bearer_token == "config-bearer-token"

# Similar tests for NewsCollector and BinanceConnector
```

## End-to-End Testing

### User Interface Tests

#### Test Cases

1. **Test Service Configuration**
   - Test adding API keys for each service
   - Test updating existing API keys
   - Test deleting API keys
   - Test service validation

2. **Test UI Functionality**
   - Test tab navigation
   - Test form validation
   - Test notifications
   - Test confirmation dialogs

3. **Test Error Handling**
   - Test server errors
   - Test validation errors
   - Test network errors

#### Implementation Example

```javascript
// src/frontend/tests/APISettingsPage.test.jsx
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import APISettingsPage from '../admin/APISettingsPage';

// Mock axios
const mockAxios = new MockAdapter(axios);

describe('APISettingsPage', () => {
  beforeEach(() => {
    // Reset mocks
    mockAxios.reset();
    
    // Mock the services endpoint
    mockAxios.onGet('/api/settings/services').reply(200, []);
  });
  
  test('renders the page with tabs', async () => {
    render(<APISettingsPage />);
    
    // Wait for the page to load
    await waitFor(() => {
      expect(screen.getByText('API Settings')).toBeInTheDocument();
    });
    
    // Check that tabs are rendered
    expect(screen.getByText('Twitter API')).toBeInTheDocument();
    expect(screen.getByText('Binance API')).toBeInTheDocument();
    expect(screen.getByText('News API')).toBeInTheDocument();
    expect(screen.getByText('All Keys')).toBeInTheDocument();
  });
  
  test('allows adding API keys', async () => {
    // Mock the API endpoints
    mockAxios.onPost('/api/settings/keys').reply(201, { status: 'success' });
    
    render(<APISettingsPage />);
    
    // Wait for the page to load
    await waitFor(() => {
      expect(screen.getByText('API Settings')).toBeInTheDocument();
    });
    
    // Fill in the API key form
    const apiKeyInput = screen.getByLabelText('API Key');
    fireEvent.change(apiKeyInput, { target: { value: 'test-api-key' } });
    
    // Click the save button
    const saveButton = screen.getByText('Save');
    fireEvent.click(saveButton);
    
    // Verify the API was called
    await waitFor(() => {
      expect(mockAxios.history.post.length).toBe(1);
      expect(JSON.parse(mockAxios.history.post[0].data)).toEqual({
        service: 'twitter',
        key_name: 'api_key',
        value: 'test-api-key'
      });
    });
    
    // Verify the success notification
    expect(screen.getByText(/Saved api_key for Twitter API/)).toBeInTheDocument();
  });
  
  test('allows testing service connection', async () => {
    // Mock the API endpoints
    mockAxios.onPost('/api/settings/test/twitter').reply(200, {
      success: true,
      message: 'Successfully connected to twitter'
    });
    
    render(<APISettingsPage />);
    
    // Wait for the page to load
    await waitFor(() => {
      expect(screen.getByText('API Settings')).toBeInTheDocument();
    });
    
    // Click the test connection button
    const testButton = screen.getByText('Test Connection');
    fireEvent.click(testButton);
    
    // Verify the API was called
    await waitFor(() => {
      expect(mockAxios.history.post.length).toBe(1);
      expect(mockAxios.history.post[0].url).toBe('/api/settings/test/twitter');
    });
    
    // Verify the success notification
    expect(screen.getByText('Successfully connected to twitter')).toBeInTheDocument();
  });
  
  test('handles API errors', async () => {
    // Mock the API endpoints with an error
    mockAxios.onPost('/api/settings/keys').reply(500, { detail: 'Server error' });
    
    render(<APISettingsPage />);
    
    // Wait for the page to load
    await waitFor(() => {
      expect(screen.getByText('API Settings')).toBeInTheDocument();
    });
    
    // Fill in the API key form
    const apiKeyInput = screen.getByLabelText('API Key');
    fireEvent.change(apiKeyInput, { target: { value: 'test-api-key' } });
    
    // Click the save button
    const saveButton = screen.getByText('Save');
    fireEvent.click(saveButton);
    
    // Verify the error notification
    await waitFor(() => {
      expect(screen.getByText('Failed to save API key')).toBeInTheDocument();
    });
  });
  
  // Additional tests for tab navigation, deletion, etc.
});
```

### System Integration Tests

#### Test Cases

1. **Test Complete Workflow**
   - Configure API keys through the UI
   - Verify keys are stored securely
   - Verify components use the configured keys
   - Test data collection with real APIs

2. **Test Fallback Behavior**
   - Remove API keys and verify fallback to mock data
   - Test graceful degradation

3. **Test Security**
   - Verify encrypted storage
   - Test authentication requirements
   - Verify secure transmission

#### Implementation Example

```python
# src/tests/e2e/test_system_integration.py
import pytest
import os
import tempfile
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

@pytest.fixture
def setup_test_environment():
    # Create a temporary directory for testing
    test_dir = tempfile.mkdtemp()
    
    # Set environment variables
    os.environ["API_KEY_SECRET"] = "test-secret-key"
    os.environ["API_KEYS_PATH"] = os.path.join(test_dir, "api_keys.json")
    
    # Start the server (this would be a subprocess in a real test)
    # server_process = subprocess.Popen(["python", "src/api/run_api.py"])
    
    # Wait for server to start
    time.sleep(2)
    
    yield test_dir
    
    # Clean up
    # server_process.terminate()
    # server_process.wait()
    
    # Remove the test directory
    import shutil
    shutil.rmtree(test_dir)

@pytest.fixture
def browser():
    # Initialize the WebDriver
    driver = webdriver.Chrome()
    
    yield driver
    
    # Clean up
    driver.quit()

def test_complete_workflow(setup_test_environment, browser):
    # Navigate to the API settings page
    browser.get("http://localhost:8000/admin/api-settings")
    
    # Wait for the page to load
    WebDriverWait(browser, 10).until(
        EC.presence_of_element_located((By.XPATH, "//h4[text()='API Settings']"))
    )
    
    # Fill in the Twitter API key
    api_key_input = browser.find_element(By.XPATH, "//label[text()='API Key']/following-sibling::input")
    api_key_input.send_keys("test-api-key")
    
    # Click the save button
    save_button = browser.find_element(By.XPATH, "//button[text()='Save']")
    save_button.click()
    
    # Wait for the success notification
    WebDriverWait(browser, 10).until(
        EC.presence_of_element_located((By.XPATH, "//div[contains(text(), 'Saved api_key')]"))
    )
    
    # Verify the API key was saved
    api_keys_path = os.environ["API_KEYS_PATH"]
    assert os.path.exists(api_keys_path)
    
    # Verify the file is encrypted
    with open(api_keys_path, 'r') as f:
        data = f.read()
        assert "test-api-key" not in data
    
    # Now test that a component can use this key
    # This would require setting up a test API server and making a real request
    # For simplicity, we'll just check that the key is accessible
    
    # Import the API key manager
    from src.common.security.api_keys import get_api_key
    
    # Get the key
    key = get_api_key("twitter", "api_key")
    assert key == "test-api-key"
```

## Security Testing

### Encryption Tests

#### Test Cases

1. **Test Data Encryption**
   - Verify API keys are encrypted at rest
   - Verify encryption key derivation
   - Test with different secret keys

2. **Test Key Rotation**
   - Test changing the encryption key
   - Verify data remains accessible

#### Implementation Example

```python
# src/tests/security/test_encryption.py
import pytest
import os
import tempfile
from src.common.security.api_key_manager import APIKeyManager

def test_data_encryption():
    # Create a temporary file for testing
    fd, path = tempfile.mkstemp()
    os.close(fd)
    
    try:
        # Create a manager with a known secret key
        manager = APIKeyManager(config_path=path, secret_key="test-secret-key")
        
        # Set a key
        manager.set_api_key("test", "api_key", "sensitive-value")
        
        # Verify the file exists
        assert os.path.exists(path)
        
        # Read the file content
        with open(path, 'r') as f:
            encrypted_data = f.read()
        
        # Verify the sensitive value is not in the file
        assert "sensitive-value" not in encrypted_data
        
        # Verify the data is encrypted (should start with Fernet token prefix)
        assert encrypted_data.startswith('gAAAAA')
        
        # Create a new manager with the same secret key
        new_manager = APIKeyManager(config_path=path, secret_key="test-secret-key")
        
        # Verify the key can be retrieved
        assert new_manager.get_api_key("test", "api_key") == "sensitive-value"
        
        # Create a manager with a different secret key
        wrong_key_manager = APIKeyManager(config_path=path, secret_key="wrong-secret-key")
        
        # Verify the key cannot be retrieved
        assert wrong_key_manager.get_api_key("test", "api_key") is None
    finally:
        # Clean up
        if os.path.exists(path):
            os.unlink(path)

def test_key_rotation():
    # Create a temporary file for testing
    fd, path = tempfile.mkstemp()
    os.close(fd)
    
    try:
        # Create a manager with an initial secret key
        manager = APIKeyManager(config_path=path, secret_key="initial-secret-key")
        
        # Set some keys
        manager.set_api_key("test", "api_key", "sensitive-value")
        
        # Create a new file for the rotated keys
        fd2, new_path = tempfile.mkstemp()
        os.close(fd2)
        
        # Create a manager with a new secret key
        new_manager = APIKeyManager(config_path=new_path, secret_key="new-secret-key")
        
        # Rotate the keys
        for service, config in manager.api_keys.items():
            for key_name, value in config.items():
                if not key_name.startswith('_'):
                    new_manager.set_api_key(service, key_name, value)
        
        # Verify the keys were rotated
        assert new_manager.get_api_key("test", "api_key") == "sensitive-value"
        
        # Verify the new file is encrypted with the new key
        with open(new_path, 'r') as f:
            encrypted_data = f.read()
        
        # Verify the sensitive value is not in the file
        assert "sensitive-value" not in encrypted_data
    finally:
        # Clean up
        if os.path.exists(path):
            os.unlink(path)
        if os.path.exists(new_path):
            os.unlink(new_path)
```

### Authentication Tests

#### Test Cases

1. **Test Authentication Requirements**
   - Verify endpoints require authentication
   - Test with valid credentials
   - Test with invalid credentials

2. **Test Authorization**
   - Verify only admins can access the API settings
   - Test with different user roles

#### Implementation Example

```python
# src/tests/security/test_authentication.py
import pytest
from fastapi.testclient import TestClient
from src.api.main import app
import jwt
import time

# Create a test client
client = TestClient(app)

def create_test_token(username, role, expired=False):
    """Create a test JWT token."""
    # Get the secret key from the app
    secret_key = "test-secret-key"  # This should match your app's secret key
    
    # Create the payload
    payload = {
        "sub": username,
        "role": role,
        "exp": int(time.time()) - 3600 if expired else int(time.time()) + 3600
    }
    
    # Create the token
    token = jwt.encode(payload, secret_key, algorithm="HS256")
    
    return token

def test_authentication_required():
    """Test that endpoints require authentication."""
    # Try to access the endpoints without authentication
    response = client.get("/api/settings/services")
    assert response.status_code == 401
    
    response = client.post(
        "/api/settings/keys",
        json={"service": "test", "key_name": "api_key", "value": "test-value"}
    )
    assert response.status_code == 401

def test_valid_authentication():
    """Test that endpoints work with valid authentication."""
    # Create a valid admin token
    token = create_test_token("admin", "admin")
    
    # Try to access the endpoints with authentication
    response = client.get(
        "/api/settings/services",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 200
    
    response = client.post(
        "/api/settings/keys",
        json={"service": "test", "key_name": "api_key", "value": "test-value"},
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 201

def test_expired_token():
    """Test that expired tokens are rejected."""
    # Create an expired token
    token = create_test_token("admin", "admin", expired=True)
    
    # Try to access the endpoints with the expired token
    response = client.get(
        "/api/settings/services",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 401

def test_authorization():
    """Test that only admins can access the API settings."""
    # Create a non-admin token
    token = create_test_token("user", "user")
    
    # Try to access the endpoints with the non-admin token
    response = client.get(
        "/api/settings/services",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 403
```

## Performance Testing

### Load Testing

#### Test Cases

1. **Test API Key Retrieval Performance**
   - Measure retrieval time under load
   - Test with different numbers of keys
   - Identify performance bottlenecks

2. **Test API Endpoint Performance**
   - Measure response time under load
   - Test with concurrent requests
   - Identify performance bottlenecks

#### Implementation Example

```python
# src/tests/performance/test_api_key_manager_performance.py
import pytest
import time
import tempfile
import os
from src.common.security.api_key_manager import APIKeyManager

@pytest.fixture
def api_key_manager():
    # Create a temporary file for testing
    fd, path = tempfile.mkstemp()
    os.close(fd)
    
    # Create manager with test secret key
    manager = APIKeyManager(config_path=path, secret_key="test-secret-key")
    
    yield manager
    
    # Clean up
    if os.path.exists(path):
        os.unlink(path)

def test_retrieval_performance(api_key_manager):
    """Test API key retrieval performance."""
    # Set up a large number of keys
    num_services = 100
    num_keys_per_service = 10
    
    for i in range(num_services):
        for j in range(num_keys_per_service):
            api_key_manager.set_api_key(f"service{i}", f"key{j}", f"value{i}-{j}")
    
    # Measure retrieval time
    start_time = time.time()
    
    for i in range(num_services):
        for j in range(num_keys_per_service):
            api_key_manager.get_api_key(f"service{i}", f"key{j}")
    
    end_time = time.time()
    
    # Calculate average retrieval time
    total_retrievals = num_services * num_keys_per_service
    total_time = end_time - start_time
    avg_time = total_time / total_retrievals
    
    # Assert that retrieval is fast enough
    assert avg_time < 0.001  # Less than 1ms per retrieval

def test_save_performance(api_key_manager):
    """Test API key save performance."""
    # Measure save time for different numbers of keys
    num_keys = [10, 100, 1000]
    times = []
    
    for n in num_keys:
        # Clear existing keys
        api_key_manager.api_keys = {}
        
        # Measure time to save n keys
        start_time = time.time()
        
        for i in range(n):
            api_key_manager.set_api_key("test", f"key{i}", f"value{i}")
        
        end_time = time.time()
        times.append(end_time - start_time)
    
    # Print the results
    for n, t in zip(num_keys, times):
        print(f"Time to save {n} keys: {t:.4f}s")
    
    # Assert that save time scales reasonably
    # The time to save 1000 keys should be less than 100 times the time to save 10 keys
    assert times[2] < times[0] * 100
```

### Stress Testing

#### Test Cases

1. **Test System Under Heavy Load**
   - Test with a large number of API keys
   - Test with frequent updates
   - Test with concurrent access

2. **Test Recovery**
   - Test system recovery after failures
   - Test with corrupted data
   - Test with resource limitations

#### Implementation Example

```python
# src/tests/performance/test_stress.py
import pytest
import asyncio
import tempfile
import os
import random
import string
from src.common.security.api_key_manager import APIKeyManager

@pytest.fixture
def api_key_manager():
    # Create a temporary file for testing
    fd, path = tempfile.mkstemp()
    os.close(fd)
    
    # Create manager with test secret key
    manager = APIKeyManager(config_path=path, secret_key="test-secret-key")
    
    yield manager
    
    # Clean up
    if os.path.exists(path):
        os.unlink(path)

def random_string(length=10):
    """Generate a random string."""
    return ''.join(random.choice(string.ascii_letters) for _ in range(length))

@pytest.mark.asyncio
async def test_concurrent_access(api_key_manager):
    """Test concurrent access to the API key manager."""
    # Number of concurrent tasks
    num_tasks = 100
    
    # Create tasks for setting keys
    async def set_key():
        service = f"service{random.randint(1, 10)}"
        key_name = f"key{random.randint(1, 10)}"
        value = random_string()
        api_key_manager.set_api_key(service, key_name, value)
        return service, key_name, value
    
    # Run tasks concurrently
    tasks = [asyncio.create_task(set_key()) for _ in range(num_tasks)]
    results = await asyncio.gather(*tasks)
    
    # Verify all keys were set correctly
    for service, key_name, value in results:
        assert api_key_manager.get_api_key(service, key_name) == value

@pytest.mark.asyncio
async def test_recovery_from_corruption(api_key_manager):
    """Test recovery from corrupted data."""
    # Set some keys
    api_key_manager.set_api_key("test", "api_key", "test-value")
    
    # Corrupt the file
    with open(api_key_manager.config_path, 'w') as f:
        f.write("corrupted data")
    
    # Create a new manager with the same path
    new_manager = APIKeyManager(
        config_path=api_key_manager.config_path,
        secret_key="test-secret-key"
    )
    
    # Verify it starts with an empty configuration
    assert new_manager.api_keys == {}
    
    # Set a new key
    new_manager.set_api_key("test", "new_key", "new-value")
    
    # Verify the key was set
    assert new_manager.get_api_key("test", "new_key") == "new-value"
```

## Test Automation

### Continuous Integration

Set up CI/CD pipelines to run tests automatically:

```yaml
# .github/workflows/test.yml
name: Test

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: 3.9
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install pytest pytest-asyncio pytest-cov
        pip install -r requirements.txt
    
    - name: Run tests
      run: |
        pytest --cov=src tests/
    
    - name: Upload coverage report
      uses: codecov/codecov-action@v1
```

### Test Reports

Generate test reports for better visibility:

```python
# pytest.ini
[pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = --cov=src --cov-report=xml --cov-report=html
```

## Test Environment Setup

### Local Development

Set up a local test environment:

```bash
# setup_test_env.sh
#!/bin/bash

# Create a virtual environment
python -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
pip install pytest pytest-asyncio pytest-cov

# Set environment variables
export API_KEY_SECRET="test-secret-key"
export API_KEYS_PATH="./test_api_keys.json"

# Run tests
pytest
```

### CI Environment

Set up a CI test environment:

```yaml
# docker-compose.test.yml
version: '3'

services:
  app:
    build: .
    environment:
      - API_KEY_SECRET=test-secret-key
      - API_KEYS_PATH=/app/test_api_keys.json
    command: pytest
```

## Test Data Management

### Test Data Generation

Generate test data for different scenarios:

```python
# src/tests/utils/test_data.py
import random
import string
from typing import Dict, Any

def random_string(length=10):
    """Generate a random string."""
    return ''.join(random.choice(string.ascii_letters) for _ in range(length))

def generate_api_keys(num_services=5, num_keys_per_service=3):
    """Generate test API keys."""
    api_keys = {}
    
    for i in range(num_services):
        service = f"service{i}"
        api_keys[service] = {}
        
        for j in range(num_keys_per_service):
            key_name = f"key{j}"
            value = random_string()
            api_keys[service][key_name] = value
    
    return api_keys

def generate_service_info(api_keys: Dict[str, Dict[str, Any]]):
    """Generate service info for API responses."""
    services = []
    
    for service, keys in api_keys.items():
        services.append({
            "service": service,
            "configured": True,
            "last_updated": "2023-01-01T00:00:00",
            "keys": list(keys.keys()),
            "validated": random.choice([True, False])
        })
    
    return services
```

### Test Data Cleanup

Clean up test data after tests:

```python
# src/tests/conftest.py
import pytest
import os
import tempfile
import shutil

@pytest.fixture(scope="session")
def test_dir():
    """Create a temporary directory for test data."""
    # Create a temporary directory
    test_dir = tempfile.mkdtemp()
    
    yield test_dir
    
    # Clean up
    shutil.rmtree(test_dir)

@pytest.fixture
def test_file(test_dir):
    """Create a temporary file for testing."""
    # Create a temporary file
    fd, path = tempfile.mkstemp(dir=test_dir)
    os.close(fd)
    
    yield path
    
    # Clean up
    if os.path.exists(path):
        os.unlink(path)
```

## Test Execution Plan

### Test Prioritization

Prioritize tests based on risk and importance:

1. **Critical Tests**
   - Security tests for encryption and authentication
   - Core functionality tests for API key management
   - Integration tests with existing components

2. **High Priority Tests**
   - API endpoint tests
   - UI functionality tests
   - Error handling tests

3. **Medium Priority Tests**
   - Performance tests
   - Stress tests
   - Edge case tests

4. **Low Priority Tests**
   - UI styling tests
   - Documentation tests
   - Compatibility tests

### Test Execution Schedule

Schedule tests to run at different stages:

1. **Pre-Commit Tests**
   - Unit tests
   - Linting
   - Code style checks

2. **CI Tests**
   - Unit tests
   - Integration tests
   - Security tests

3. **Nightly Tests**
   - Performance tests
   - Stress tests
   - End-to-end tests

4. **Release Tests**
   - All tests
   - Compatibility tests
   - Deployment tests

## Defect Management

### Defect Tracking

Track defects using a standard format:

```
# Defect Report Template

## Summary
[Brief description of the issue]

## Steps to Reproduce
1. [First step]
2. [Second step]
3. [...]

## Expected Result
[What should happen]

## Actual Result
[What actually happens]

## Environment
- OS: [e.g., Windows 10, Ubuntu 20.04]
- Browser: [e.g., Chrome 90, Firefox 88]
- API Key Manager Version: [e.g., 1.0.0]

## Severity
[Critical/High/Medium/Low]

## Priority
[High/Medium/Low]

## Screenshots
[If applicable]

## Additional Information
[Any other relevant information]
```

### Defect Resolution

Define a process for resolving defects:

1. **Triage**
   - Assess severity and priority
   - Assign to a developer
   - Set a target resolution date

2. **Investigation**
   - Reproduce the issue
   - Identify the root cause
   - Determine the fix

3. **Resolution**
   - Implement the fix
   - Write tests to prevent regression
   - Document the solution

4. **Verification**
   - Verify the fix works
   - Run regression tests
   - Update documentation if needed

5. **Closure**
   - Close the defect
   - Update the release notes
   - Communicate the fix to stakeholders

## Conclusion

This testing strategy provides a comprehensive approach to testing the API Key Management System. By following this strategy, you can ensure that the system functions correctly, securely, and efficiently.

The strategy covers all aspects of testing, from unit tests to end-to-end tests, and provides detailed examples of how to implement each type of test. It also includes guidance on test automation, test environment setup, test data management, test execution planning, and defect management.

By implementing this testing strategy, you can have confidence that the API Key Management System will meet the requirements and provide a reliable solution for managing API keys in the AI Trading Agent project.
