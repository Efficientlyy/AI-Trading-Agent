# API Key Management System Implementation Guide

## Overview

This document provides comprehensive implementation instructions for integrating a secure API Key Management System into the AI Trading Agent project. The system will enable administrators to manage API keys for various services (exchanges, social media, news) through a centralized web interface, eliminating the need for hardcoded credentials and facilitating the transition from mock data to real data.

## Table of Contents

1. [System Architecture](#system-architecture)
2. [Backend Implementation](#backend-implementation)
   - [API Key Manager](#api-key-manager)
   - [API Endpoints](#api-endpoints)
   - [Service Validators](#service-validators)
3. [Frontend Implementation](#frontend-implementation)
   - [Admin Interface](#admin-interface)
   - [Component Structure](#component-structure)
4. [Integration with Existing Components](#integration-with-existing-components)
   - [Data Collectors](#data-collectors)
   - [Exchange Connectors](#exchange-connectors)
5. [Security Considerations](#security-considerations)
6. [Testing Strategy](#testing-strategy)
7. [Deployment Instructions](#deployment-instructions)
8. [Implementation Timeline](#implementation-timeline)

## System Architecture

The API Key Management System consists of the following components:

1. **API Key Manager**: Core backend service for securely storing and retrieving API keys
2. **REST API Endpoints**: Interface for the frontend to manage API keys
3. **Service Validators**: Components to validate API keys for each service
4. **Admin Interface**: Web UI for managing API keys
5. **Integration Layer**: Modifications to existing components to use the API Key Manager

![Architecture Diagram](https://i.imgur.com/example.png)

## Backend Implementation

### API Key Manager

Create a new file at `src/common/security/api_key_manager.py`:

```python
import os
import json
import base64
import logging
from datetime import datetime
from typing import Dict, Any, Optional
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

class APIKeyManager:
    """Secure API key management service."""
    
    def __init__(self, config_path: str = None, secret_key: str = None):
        """Initialize the API key manager.
        
        Args:
            config_path: Path to the API keys configuration file
            secret_key: Secret key for encryption (if None, uses environment variable)
        """
        self.logger = logging.getLogger("api_key_manager")
        self.config_path = config_path or os.path.join(os.path.dirname(__file__), "api_keys.json")
        
        # Initialize encryption
        self._init_encryption(secret_key)
        
        # Load existing configuration
        self.api_keys = self._load_config()
        
        # Cache for validated keys
        self.validated_keys = {}
        
    def _init_encryption(self, secret_key: str = None) -> None:
        """Initialize encryption for API keys."""
        # Get secret key from environment if not provided
        key = secret_key or os.environ.get("API_KEY_SECRET", "default-secret-key-change-in-production")
        
        # Derive a proper key using PBKDF2
        salt = b'api-key-manager-salt'  # In production, this should be stored securely
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        derived_key = base64.urlsafe_b64encode(kdf.derive(key.encode()))
        
        # Create Fernet cipher
        self.cipher = Fernet(derived_key)
        
    def _load_config(self) -> Dict[str, Any]:
        """Load API key configuration from file."""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r') as f:
                    encrypted_data = f.read()
                    if encrypted_data:
                        decrypted_data = self.cipher.decrypt(encrypted_data.encode()).decode()
                        return json.loads(decrypted_data)
            return {}
        except Exception as e:
            self.logger.error(f"Error loading API key configuration: {e}")
            return {}
            
    def _save_config(self) -> bool:
        """Save API key configuration to file."""
        try:
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            
            # Encrypt the configuration
            encrypted_data = self.cipher.encrypt(json.dumps(self.api_keys).encode()).decode()
            
            # Save to file
            with open(self.config_path, 'w') as f:
                f.write(encrypted_data)
            return True
        except Exception as e:
            self.logger.error(f"Error saving API key configuration: {e}")
            return False
            
    def get_api_key(self, service: str, key_name: str) -> Optional[str]:
        """Get an API key for a service.
        
        Args:
            service: Service identifier (e.g., "twitter", "binance")
            key_name: Name of the key (e.g., "api_key", "secret_key")
            
        Returns:
            API key value or None if not found
        """
        return self.api_keys.get(service, {}).get(key_name)
        
    def set_api_key(self, service: str, key_name: str, value: str) -> bool:
        """Set an API key for a service.
        
        Args:
            service: Service identifier (e.g., "twitter", "binance")
            key_name: Name of the key (e.g., "api_key", "secret_key")
            value: API key value
            
        Returns:
            True if successful, False otherwise
        """
        # Initialize service if not exists
        if service not in self.api_keys:
            self.api_keys[service] = {}
            
        # Set the key
        self.api_keys[service][key_name] = value
        
        # Add metadata
        self.api_keys[service]["_last_updated"] = datetime.utcnow().isoformat()
        
        # Save configuration
        return self._save_config()
        
    def delete_api_key(self, service: str, key_name: str = None) -> bool:
        """Delete an API key or entire service configuration.
        
        Args:
            service: Service identifier (e.g., "twitter", "binance")
            key_name: Name of the key to delete, or None to delete entire service
            
        Returns:
            True if successful, False otherwise
        """
        if service not in self.api_keys:
            return False
            
        if key_name:
            if key_name in self.api_keys[service]:
                del self.api_keys[service][key_name]
        else:
            del self.api_keys[service]
            
        # Save configuration
        return self._save_config()
        
    def list_services(self) -> Dict[str, Dict[str, Any]]:
        """List all configured services with metadata.
        
        Returns:
            Dictionary of services with their metadata
        """
        result = {}
        for service, config in self.api_keys.items():
            # Create a copy without the actual key values for security
            service_info = {
                "configured": True,
                "last_updated": config.get("_last_updated", "unknown"),
                "keys": [k for k in config.keys() if not k.startswith("_")]
            }
            result[service] = service_info
        return result
        
    async def validate_api_key(self, service: str, validator_func) -> bool:
        """Validate API keys for a service using a validator function.
        
        Args:
            service: Service identifier (e.g., "twitter", "binance")
            validator_func: Async function that validates the keys
            
        Returns:
            True if valid, False otherwise
        """
        try:
            # Check if we have keys for this service
            if service not in self.api_keys:
                return False
                
            # Call the validator function
            is_valid = await validator_func(self.api_keys[service])
            
            # Update validation status
            if is_valid:
                self.validated_keys[service] = datetime.utcnow().isoformat()
                
            return is_valid
        except Exception as e:
            self.logger.error(f"Error validating API keys for {service}: {e}")
            return False
```

### API Endpoints

Create a new file at `src/api/routes/api_settings.py`:

```python
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from typing import Dict, List, Optional, Any
import asyncio

from src.common.security.api_key_manager import APIKeyManager
from src.common.security.auth import get_current_admin_user

# Initialize API key manager
api_key_manager = APIKeyManager()

# Create router
router = APIRouter(
    prefix="/api/settings",
    tags=["settings"],
    dependencies=[Depends(get_current_admin_user)]
)

# Models
class APIKeyInput(BaseModel):
    service: str
    key_name: str
    value: str

class ServiceInfo(BaseModel):
    service: str
    configured: bool
    last_updated: Optional[str]
    keys: List[str]
    validated: Optional[bool]
    
class TestResult(BaseModel):
    success: bool
    message: str

# Routes
@router.get("/services", response_model=List[ServiceInfo])
async def list_services():
    """List all configured services."""
    services = api_key_manager.list_services()
    result = []
    
    for service, info in services.items():
        result.append(ServiceInfo(
            service=service,
            configured=info["configured"],
            last_updated=info["last_updated"],
            keys=info["keys"],
            validated=service in api_key_manager.validated_keys
        ))
    
    return result

@router.post("/keys", status_code=status.HTTP_201_CREATED)
async def set_api_key(key_input: APIKeyInput):
    """Set an API key."""
    success = api_key_manager.set_api_key(
        key_input.service, 
        key_input.key_name, 
        key_input.value
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to save API key"
        )
    
    return {"status": "success"}

@router.delete("/keys/{service}/{key_name}")
async def delete_api_key(service: str, key_name: str):
    """Delete an API key."""
    success = api_key_manager.delete_api_key(service, key_name)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"API key {key_name} for service {service} not found"
        )
    
    return {"status": "success"}

@router.delete("/services/{service}")
async def delete_service(service: str):
    """Delete all API keys for a service."""
    success = api_key_manager.delete_api_key(service)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Service {service} not found"
        )
    
    return {"status": "success"}

@router.post("/test/{service}", response_model=TestResult)
async def test_service_connection(service: str):
    """Test connection to a service using stored API keys."""
    # Import validators dynamically to avoid circular imports
    from src.common.security.api_validators import get_validator_for_service
    
    validator = get_validator_for_service(service)
    if not validator:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"No validator available for service {service}"
        )
    
    is_valid = await api_key_manager.validate_api_key(service, validator)
    
    if is_valid:
        return TestResult(
            success=True,
            message=f"Successfully connected to {service}"
        )
    else:
        return TestResult(
            success=False,
            message=f"Failed to connect to {service}. Please check your API keys."
        )
```

Add the router to your main FastAPI app in `src/api/main.py`:

```python
from fastapi import FastAPI
from src.api.routes import api_settings

app = FastAPI(title="AI Trading Agent API")

# Include routers
app.include_router(api_settings.router)
```

### Service Validators

Create a new file at `src/common/security/api_validators.py`:

```python
import asyncio
from typing import Dict, Any, Callable, Awaitable

# Import clients
from src.analysis_agents.early_detection.data_collectors.twitter_collector import TwitterCollector
from src.data_collection.connectors.binance import BinanceConnector
from src.analysis_agents.news.news_api_client import NewsAPIClient

async def validate_twitter_keys(keys: Dict[str, str]) -> bool:
    """Validate Twitter API keys."""
    try:
        # Create a temporary collector
        collector = TwitterCollector()
        
        # Set keys
        collector.api_key = keys.get("api_key", "")
        collector.api_secret = keys.get("api_secret", "")
        collector.bearer_token = keys.get("bearer_token", "")
        
        # Initialize and test
        await collector.initialize()
        
        # Check if we're using mock data
        return not collector.use_mock
    except Exception:
        return False

async def validate_binance_keys(keys: Dict[str, str]) -> bool:
    """Validate Binance API keys."""
    try:
        # Create a temporary connector
        connector = BinanceConnector()
        
        # Initialize REST client
        await connector._init_rest_client()
        
        # Try to fetch available symbols
        symbols = await connector.fetch_available_symbols()
        
        # If we got symbols, the connection works
        return len(symbols) > 0
    except Exception:
        return False

async def validate_newsapi_keys(keys: Dict[str, str]) -> bool:
    """Validate NewsAPI keys."""
    try:
        # Create a temporary client
        client = NewsAPIClient(api_key=keys.get("api_key", ""))
        
        # Try to fetch top headlines
        articles = await client.get_top_headlines(
            language="en",
            page_size=1
        )
        
        # If we got articles, the connection works
        return articles is not None and "articles" in articles
    except Exception:
        return False

# Map of service names to validator functions
VALIDATORS = {
    "twitter": validate_twitter_keys,
    "binance": validate_binance_keys,
    "newsapi": validate_newsapi_keys,
}

def get_validator_for_service(service: str) -> Callable[[Dict[str, str]], Awaitable[bool]]:
    """Get validator function for a service."""
    return VALIDATORS.get(service)
```

## Frontend Implementation

### Admin Interface

Create a new React component at `src/frontend/admin/APISettingsPage.jsx`:

```jsx
import React, { useState, useEffect } from 'react';
import { 
  Container, Typography, Paper, Tabs, Tab, Box, 
  TextField, Button, Snackbar, Alert, CircularProgress,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle
} from '@mui/material';
import { styled } from '@mui/material/styles';
import axios from 'axios';

// Styled components
const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  marginBottom: theme.spacing(3),
}));

const KeyField = styled(TextField)(({ theme }) => ({
  marginBottom: theme.spacing(2),
}));

const APISettingsPage = () => {
  // State
  const [activeTab, setActiveTab] = useState(0);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [testingService, setTestingService] = useState(null);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'info' });
  const [deleteDialog, setDeleteDialog] = useState({ open: false, service: null, keyName: null });
  const [formData, setFormData] = useState({
    twitter: { api_key: '', api_secret: '', bearer_token: '' },
    binance: { api_key: '', api_secret: '' },
    newsapi: { api_key: '' },
  });

  // Service definitions
  const serviceDefinitions = {
    twitter: {
      name: 'Twitter API',
      description: 'Used for social media sentiment analysis and early event detection',
      fields: [
        { name: 'api_key', label: 'API Key', type: 'password' },
        { name: 'api_secret', label: 'API Secret', type: 'password' },
        { name: 'bearer_token', label: 'Bearer Token', type: 'password' },
      ],
      instructions: 'Get your Twitter API credentials from the Twitter Developer Portal',
    },
    binance: {
      name: 'Binance API',
      description: 'Used for market data and trading',
      fields: [
        { name: 'api_key', label: 'API Key', type: 'password' },
        { name: 'api_secret', label: 'API Secret', type: 'password' },
      ],
      instructions: 'Get your Binance API credentials from your Binance account settings',
    },
    newsapi: {
      name: 'News API',
      description: 'Used for news data collection',
      fields: [
        { name: 'api_key', label: 'API Key', type: 'password' },
      ],
      instructions: 'Get your News API key from newsapi.org',
    },
  };

  // Tab names based on service definitions
  const tabNames = Object.keys(serviceDefinitions).map(key => serviceDefinitions[key].name);

  // Load services on component mount
  useEffect(() => {
    fetchServices();
  }, []);

  // Fetch services from API
  const fetchServices = async () => {
    setLoading(true);
    try {
      const response = await axios.get('/api/settings/services');
      setServices(response.data);
    } catch (error) {
      showNotification('Failed to load services', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Handle tab change
  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  // Handle form input change
  const handleInputChange = (service, field, value) => {
    setFormData(prev => ({
      ...prev,
      [service]: {
        ...prev[service],
        [field]: value
      }
    }));
  };

  // Save API key
  const saveApiKey = async (service, keyName, value) => {
    if (!value) return;
    
    try {
      await axios.post('/api/settings/keys', {
        service,
        key_name: keyName,
        value
      });
      
      showNotification(`Saved ${keyName} for ${serviceDefinitions[service].name}`, 'success');
      fetchServices();
    } catch (error) {
      showNotification('Failed to save API key', 'error');
    }
  };

  // Test service connection
  const testServiceConnection = async (service) => {
    setTestingService(service);
    try {
      const response = await axios.post(`/api/settings/test/${service}`);
      showNotification(response.data.message, response.data.success ? 'success' : 'error');
    } catch (error) {
      showNotification(`Error testing connection: ${error.message}`, 'error');
    } finally {
      setTestingService(null);
    }
  };

  // Delete API key
  const deleteApiKey = async () => {
    const { service, keyName } = deleteDialog;
    
    try {
      if (keyName) {
        await axios.delete(`/api/settings/keys/${service}/${keyName}`);
        showNotification(`Deleted ${keyName} for ${serviceDefinitions[service].name}`, 'success');
      } else {
        await axios.delete(`/api/settings/services/${service}`);
        showNotification(`Deleted all keys for ${serviceDefinitions[service].name}`, 'success');
      }
      
      fetchServices();
      setDeleteDialog({ open: false, service: null, keyName: null });
    } catch (error) {
      showNotification('Failed to delete API key', 'error');
    }
  };

  // Show notification
  const showNotification = (message, severity = 'info') => {
    setNotification({ open: true, message, severity });
  };

  // Close notification
  const closeNotification = () => {
    setNotification({ ...notification, open: false });
  };

  // Render service form
  const renderServiceForm = (serviceKey) => {
    const service = serviceDefinitions[serviceKey];
    const serviceInfo = services.find(s => s.service === serviceKey);
    const isConfigured = serviceInfo?.configured || false;
    const isValidated = serviceInfo?.validated || false;
    
    return (
      <StyledPaper elevation={3}>
        <Typography variant="h5" gutterBottom>{service.name}</Typography>
        <Typography variant="body1" paragraph>{service.description}</Typography>
        
        {isConfigured && (
          <Box mb={3}>
            <Typography variant="subtitle2" color="primary">
              Status: Configured {isValidated ? '(Validated)' : '(Not Validated)'}
            </Typography>
            <Typography variant="caption">
              Last Updated: {serviceInfo?.last_updated || 'Unknown'}
            </Typography>
          </Box>
        )}
        
        <Typography variant="subtitle2" gutterBottom>API Credentials</Typography>
        <Typography variant="caption" paragraph>{service.instructions}</Typography>
        
        {service.fields.map((field) => (
          <KeyField
            key={field.name}
            label={field.label}
            type={field.type}
            fullWidth
            value={formData[serviceKey][field.name]}
            onChange={(e) => handleInputChange(serviceKey, field.name, e.target.value)}
            InputProps={{
              endAdornment: (
                <Button 
                  variant="contained" 
                  size="small"
                  onClick={() => saveApiKey(serviceKey, field.name, formData[serviceKey][field.name])}
                >
                  Save
                </Button>
              ),
            }}
          />
        ))}
        
        <Box display="flex" justifyContent="space-between" mt={3}>
          <Button 
            variant="contained" 
            color="primary"
            disabled={testingService === serviceKey}
            onClick={() => testServiceConnection(serviceKey)}
          >
            {testingService === serviceKey ? <CircularProgress size={24} /> : 'Test Connection'}
          </Button>
          
          {isConfigured && (
            <Button 
              variant="outlined" 
              color="error"
              onClick={() => setDeleteDialog({ open: true, service: serviceKey, keyName: null })}
            >
              Delete All Keys
            </Button>
          )}
        </Box>
      </StyledPaper>
    );
  };

  // Render service keys table
  const renderServiceKeysTable = () => {
    return (
      <StyledPaper elevation={3}>
        <Typography variant="h5" gutterBottom>All API Keys</Typography>
        
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Service</TableCell>
                <TableCell>Key Name</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Last Updated</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {services.flatMap(service => 
                service.keys.map(keyName => (
                  <TableRow key={`${service.service}-${keyName}`}>
                    <TableCell>{serviceDefinitions[service.service]?.name || service.service}</TableCell>
                    <TableCell>{keyName}</TableCell>
                    <TableCell>{service.validated ? 'Validated' : 'Not Validated'}</TableCell>
                    <TableCell>{service.last_updated || 'Unknown'}</TableCell>
                    <TableCell>
                      <Button 
                        size="small" 
                        color="error"
                        onClick={() => setDeleteDialog({ 
                          open: true, 
                          service: service.service, 
                          keyName: keyName 
                        })}
                      >
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
              {services.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} align="center">No API keys configured</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </StyledPaper>
    );
  };

  return (
    <Container maxWidth="lg">
      <Typography variant="h4" component="h1" gutterBottom>API Settings</Typography>
      
      {loading ? (
        <Box display="flex" justifyContent="center" my={5}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          <Tabs
            value={activeTab}
            onChange={handleTabChange}
            indicatorColor="primary"
            textColor="primary"
            variant="scrollable"
            scrollButtons="auto"
          >
            {tabNames.map((name, index) => (
              <Tab key={index} label={name} />
            ))}
            <Tab label="All Keys" />
          </Tabs>
          
          <Box my={3}>
            {Object.keys(serviceDefinitions).map((key, index) => (
              <Box key={key} hidden={activeTab !== index}>
                {activeTab === index && renderServiceForm(key)}
              </Box>
            ))}
            
            <Box hidden={activeTab !== tabNames.length}>
              {activeTab === tabNames.length && renderServiceKeysTable()}
            </Box>
          </Box>
        </>
      )}
      
      {/* Notification */}
      <Snackbar open={notification.open} autoHideDuration={6000} onClose={closeNotification}>
        <Alert onClose={closeNotification} severity={notification.severity}>
          {notification.message}
        </Alert>
      </Snackbar>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onClose={() => setDeleteDialog({ ...deleteDialog, open: false })}>
        <DialogTitle>Confirm Deletion</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {deleteDialog.keyName 
              ? `Are you sure you want to delete the ${deleteDialog.keyName} for ${serviceDefinitions[deleteDialog.service]?.name}?`
              : `Are you sure you want to delete all API keys for ${serviceDefinitions[deleteDialog.service]?.name}?`
            }
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog({ ...deleteDialog, open: false })}>Cancel</Button>
          <Button onClick={deleteApiKey} color="error" autoFocus>Delete</Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default APISettingsPage;
```

Add the component to your frontend routes:

```jsx
// src/frontend/routes.jsx
import React from 'react';
import { Route, Switch } from 'react-router-dom';
import APISettingsPage from './admin/APISettingsPage';

const Routes = () => {
  return (
    <Switch>
      <Route path="/admin/api-settings" component={APISettingsPage} />
      {/* Other routes */}
    </Switch>
  );
};

export default Routes;
```

### Component Structure

The frontend component structure should be:

```
src/
└── frontend/
    ├── admin/
    │   └── APISettingsPage.jsx
    ├── components/
    │   ├── common/
    │   │   └── ...
    │   └── ...
    ├── routes.jsx
    └── App.jsx
```

## Integration with Existing Components

### Helper Function

Create a new file at `src/common/security/api_keys.py`:

```python
from src.common.security.api_key_manager import APIKeyManager

# Singleton instance
_api_key_manager = None

def get_api_key_manager() -> APIKeyManager:
    """Get the API key manager singleton instance."""
    global _api_key_manager
    if _api_key_manager is None:
        _api_key_manager = APIKeyManager()
    return _api_key_manager

def get_api_key(service: str, key_name: str) -> str:
    """Get an API key for a service.
    
    Args:
        service: Service identifier (e.g., "twitter", "binance")
        key_name: Name of the key (e.g., "api_key", "secret_key")
        
    Returns:
        API key value or None if not found
    """
    manager = get_api_key_manager()
    return manager.get_api_key(service, key_name)
```

### Data Collectors

Modify the Twitter collector initialization in `src/analysis_agents/early_detection/data_collectors/twitter_collector.py`:

```python
def __init__(self):
    """Initialize the Twitter collector."""
    self.logger = get_logger("early_detection", "twitter_collector")
    
    # Configuration
    self.keywords = config.get("early_detection.data_collection.social_media.twitter.keywords", 
                              ["crypto", "bitcoin", "ethereum"])
    self.accounts = config.get("early_detection.data_collection.social_media.twitter.accounts", 
                              ["elonmusk", "cz_binance"])
    
    # API credentials - now using API key manager
    from src.common.security.api_keys import get_api_key
    self.api_key = get_api_key("twitter", "api_key") or os.getenv("TWITTER_API_KEY") or config.get("apis.twitter.api_key", "")
    self.api_secret = get_api_key("twitter", "api_secret") or os.getenv("TWITTER_API_SECRET") or config.get("apis.twitter.api_secret", "")
    self.access_token = get_api_key("twitter", "access_token") or os.getenv("TWITTER_ACCESS_TOKEN") or config.get("apis.twitter.access_token", "")
    self.access_secret = get_api_key("twitter", "access_secret") or os.getenv("TWITTER_ACCESS_SECRET") or config.get("apis.twitter.access_secret", "")
    self.bearer_token = get_api_key("twitter", "bearer_token") or os.getenv("TWITTER_BEARER_TOKEN") or config.get("apis.twitter.bearer_token", "")
    
    # Rest of initialization...
```

Similarly, modify the News collector initialization in `src/analysis_agents/early_detection/data_collectors/news_collector.py`:

```python
def __init__(self):
    """Initialize the news collector."""
    self.logger = get_logger("early_detection", "news_collector")
    
    # Configuration
    self.sources = config.get("early_detection.data_collection.news.sources", 
                             ["coindesk", "cointelegraph", "theblock", "decrypt"])
    self.keywords = config.get("early_detection.data_collection.news.keywords", 
                              ["regulation", "sec", "fed", "central bank"])
    
    # API credentials - now using API key manager
    from src.common.security.api_keys import get_api_key
    self.newsapi_key = get_api_key("newsapi", "api_key") or os.getenv("NEWSAPI_KEY") or config.get("apis.news_api.key", "")
    self.cryptocompare_key = get_api_key("cryptocompare", "api_key") or os.getenv("CRYPTOCOMPARE_KEY") or config.get("apis.cryptocompare.key", "")
    
    # Rest of initialization...
```

### Exchange Connectors

Modify the Binance connector initialization in `src/data_collection/connectors/binance.py`:

```python
def __init__(self, exchange_id: str = "binance"):
    """Initialize the Binance connector."""
    super().__init__(exchange_id)
    self.logger = get_logger("data_collection", "binance")
    
    # API credentials - now using API key manager
    from src.common.security.api_keys import get_api_key
    self.api_key = get_api_key("binance", "api_key") or os.getenv("BINANCE_API_KEY") or config.get("apis.binance.api_key", "")
    self.api_secret = get_api_key("binance", "api_secret") or os.getenv("BINANCE_API_SECRET") or config.get("apis.binance.api_secret", "")
    
    # Rest of initialization...
```

## Security Considerations

### Encryption

The API Key Manager uses Fernet symmetric encryption to protect API keys at rest. In production, consider these enhancements:

1. **Secret Key Management**:
   - Store the encryption secret key in a secure environment variable
   - Consider using a key management service (KMS) for production

2. **Salt Management**:
   - Store the salt securely, not hardcoded in the source code
   - Consider using a different salt for each deployment

3. **File Permissions**:
   - Ensure the encrypted API keys file has restricted permissions
   - Use `os.chmod(self.config_path, 0o600)` after writing the file

### Authentication

The API endpoints are protected with admin authentication. Ensure:

1. **Strong Authentication**:
   - Implement proper JWT authentication with short expiration times
   - Use HTTPS for all API communications

2. **Role-Based Access Control**:
   - Only administrators should have access to the API settings page
   - Implement proper RBAC in the `get_current_admin_user` dependency

3. **Audit Logging**:
   - Log all API key management operations with timestamps and user IDs
   - Consider implementing an audit trail for compliance

## Testing Strategy

### Unit Tests

Create unit tests for the API Key Manager:

```python
# src/tests/common/security/test_api_key_manager.py
import pytest
import os
import tempfile
from src.common.security.api_key_manager import APIKeyManager

@pytest.fixture
def api_key_manager():
    # Create a temporary file for testing
    fd, path = tempfile.mkstemp()
    os.close(fd)
    
    # Create manager with test secret key
    manager = APIKeyManager(config_path=path, secret_key="test-secret-key")
    
    yield manager
    
    # Clean up
    if os.path.exists(path):
        os.unlink(path)

def test_set_get_api_key(api_key_manager):
    # Set a key
    assert api_key_manager.set_api_key("test", "api_key", "test-value")
    
    # Get the key
    assert api_key_manager.get_api_key("test", "api_key") == "test-value"
    
    # Get a non-existent key
    assert api_key_manager.get_api_key("test", "non_existent") is None
    assert api_key_manager.get_api_key("non_existent", "api_key") is None

def test_delete_api_key(api_key_manager):
    # Set keys
    api_key_manager.set_api_key("test", "api_key", "test-value")
    api_key_manager.set_api_key("test", "secret_key", "secret-value")
    
    # Delete one key
    assert api_key_manager.delete_api_key("test", "api_key")
    assert api_key_manager.get_api_key("test", "api_key") is None
    assert api_key_manager.get_api_key("test", "secret_key") == "secret-value"
    
    # Delete entire service
    assert api_key_manager.delete_api_key("test")
    assert api_key_manager.get_api_key("test", "secret_key") is None

def test_list_services(api_key_manager):
    # Set keys for multiple services
    api_key_manager.set_api_key("service1", "api_key", "value1")
    api_key_manager.set_api_key("service2", "api_key", "value2")
    
    # List services
    services = api_key_manager.list_services()
    assert len(services) == 2
    assert "service1" in services
    assert "service2" in services
    assert "api_key" in services["service1"]["keys"]
    assert services["service1"]["configured"] is True
```

### Integration Tests

Create integration tests for the API endpoints:

```python
# src/tests/api/routes/test_api_settings.py
import pytest
from fastapi.testclient import TestClient
from src.api.main import app
from src.common.security.api_key_manager import APIKeyManager
import tempfile
import os

# Mock authentication for testing
app.dependency_overrides = {
    "src.common.security.auth.get_current_admin_user": lambda: {"username": "admin"}
}

@pytest.fixture
def client():
    # Create a temporary file for testing
    fd, path = tempfile.mkstemp()
    os.close(fd)
    
    # Override the API key manager with a test instance
    from src.api.routes.api_settings import api_key_manager
    test_manager = APIKeyManager(config_path=path, secret_key="test-secret-key")
    app.dependency_overrides["src.api.routes.api_settings.api_key_manager"] = lambda: test_manager
    
    client = TestClient(app)
    
    yield client
    
    # Clean up
    if os.path.exists(path):
        os.unlink(path)

def test_list_services_empty(client):
    response = client.get("/api/settings/services")
    assert response.status_code == 200
    assert response.json() == []

def test_set_api_key(client):
    # Set a key
    response = client.post(
        "/api/settings/keys",
        json={"service": "test", "key_name": "api_key", "value": "test-value"}
    )
    assert response.status_code == 201
    
    # Check if the key was set
    response = client.get("/api/settings/services")
    assert response.status_code == 200
    services = response.json()
    assert len(services) == 1
    assert services[0]["service"] == "test"
    assert "api_key" in services[0]["keys"]

def test_delete_api_key(client):
    # Set a key
    client.post(
        "/api/settings/keys",
        json={"service": "test", "key_name": "api_key", "value": "test-value"}
    )
    
    # Delete the key
    response = client.delete("/api/settings/keys/test/api_key")
    assert response.status_code == 200
    
    # Check if the key was deleted
    response = client.get("/api/settings/services")
    assert response.status_code == 200
    assert response.json() == []
```

### End-to-End Tests

Create end-to-end tests for the entire system:

```python
# src/tests/e2e/test_api_key_integration.py
import pytest
import asyncio
from src.common.security.api_keys import get_api_key
from src.analysis_agents.early_detection.data_collectors.twitter_collector import TwitterCollector

@pytest.mark.asyncio
async def test_twitter_collector_uses_api_key_manager():
    # Set up a mock API key manager
    from src.common.security.api_key_manager import APIKeyManager
    import tempfile
    import os
    
    # Create a temporary file for testing
    fd, path = tempfile.mkstemp()
    os.close(fd)
    
    # Create manager with test secret key
    manager = APIKeyManager(config_path=path, secret_key="test-secret-key")
    
    # Set a mock API key
    manager.set_api_key("twitter", "bearer_token", "mock-bearer-token")
    
    # Override the global API key manager
    import src.common.security.api_keys
    src.common.security.api_keys._api_key_manager = manager
    
    # Create a Twitter collector
    collector = TwitterCollector()
    
    # Check if it uses the API key from the manager
    assert collector.bearer_token == "mock-bearer-token"
    
    # Clean up
    if os.path.exists(path):
        os.unlink(path)
```

## Deployment Instructions

### Prerequisites

1. **Python Dependencies**:
   - Install cryptography: `pip install cryptography`
   - Install FastAPI: `pip install fastapi uvicorn`

2. **Frontend Dependencies**:
   - Install Material-UI: `npm install @mui/material @emotion/react @emotion/styled`
   - Install Axios: `npm install axios`

### Deployment Steps

1. **Backend Deployment**:
   - Add the new Python files to your project
   - Update the FastAPI application to include the new router
   - Set the `API_KEY_SECRET` environment variable with a secure random value

2. **Frontend Deployment**:
   - Add the React component to your frontend project
   - Update your routes to include the new page
   - Build the frontend: `npm run build`

3. **Security Configuration**:
   - Ensure HTTPS is enabled for all API communications
   - Set proper file permissions for the API keys file
   - Configure proper authentication for the admin routes

4. **Testing the Deployment**:
   - Verify the API endpoints are accessible
   - Test adding and retrieving API keys
   - Verify the integration with existing components

## Implementation Timeline

### Week 1: Backend Implementation

**Day 1-2: Core API Key Manager**
- Implement the APIKeyManager class
- Set up encryption and secure storage
- Create unit tests

**Day 3-4: API Endpoints**
- Implement the FastAPI endpoints
- Create service validators
- Set up authentication

**Day 5: Integration with Existing Components**
- Modify data collectors to use the API Key Manager
- Modify exchange connectors to use the API Key Manager
- Create integration tests

### Week 2: Frontend Implementation

**Day 1-2: Admin Interface**
- Create the React component
- Implement the service forms
- Set up API communication

**Day 3-4: UI Refinement**
- Implement validation and error handling
- Add notifications and confirmations
- Style the interface

**Day 5: Testing and Documentation**
- Create end-to-end tests
- Document the implementation
- Create user documentation

### Week 3: Deployment and Monitoring

**Day 1-2: Deployment**
- Deploy to staging environment
- Test with real API keys
- Fix any issues

**Day 3-4: Security Audit**
- Review security measures
- Implement additional safeguards
- Test for vulnerabilities

**Day 5: Monitoring and Maintenance**
- Set up monitoring for API key usage
- Create alerts for API key failures
- Document maintenance procedures

## Conclusion

This implementation guide provides a comprehensive approach to integrating a secure API Key Management System into the AI Trading Agent project. By following these instructions, you will create a centralized system for managing API keys that will facilitate the transition from mock data to real data.

The system is designed with security in mind, using encryption for API keys at rest and proper authentication for the admin interface. It also provides a user-friendly interface for managing API keys, with validation and testing capabilities.

If you have any questions or need further assistance, please don't hesitate to reach out.
