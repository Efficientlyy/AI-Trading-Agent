# API Key Management System Deployment Guide

## Overview

This document provides comprehensive deployment recommendations for the API Key Management System in the AI Trading Agent project. It covers deployment environments, configuration, security considerations, monitoring, and maintenance procedures to ensure a successful implementation.

## Table of Contents

1. [Deployment Environments](#deployment-environments)
2. [Prerequisites](#prerequisites)
3. [Configuration Management](#configuration-management)
4. [Security Considerations](#security-considerations)
5. [Deployment Process](#deployment-process)
6. [Monitoring and Logging](#monitoring-and-logging)
7. [Backup and Recovery](#backup-and-recovery)
8. [Scaling Considerations](#scaling-considerations)
9. [Maintenance Procedures](#maintenance-procedures)
10. [Troubleshooting](#troubleshooting)

## Deployment Environments

### Development Environment

The development environment is used for active development and testing:

- **Infrastructure**: Local development machines or shared development server
- **Security**: Relaxed security for development convenience, but with proper isolation
- **Data**: Test data only, no production API keys
- **Configuration**: Development-specific configuration with debug options enabled

### Staging Environment

The staging environment mirrors production for final testing:

- **Infrastructure**: Cloud-based environment similar to production
- **Security**: Production-level security measures
- **Data**: Anonymized or test API keys
- **Configuration**: Near-production configuration with additional logging

### Production Environment

The production environment hosts the live system:

- **Infrastructure**: High-availability cloud infrastructure
- **Security**: Full security measures with encryption and access controls
- **Data**: Real API keys with proper encryption
- **Configuration**: Optimized for performance and security

## Prerequisites

### System Requirements

- **Operating System**: Linux (Ubuntu 20.04 LTS or later recommended)
- **Python**: Version 3.9 or later
- **Node.js**: Version 16 or later (for frontend)
- **Database**: Not required (file-based storage)
- **Memory**: Minimum 2GB RAM
- **Storage**: Minimum 10GB available disk space

### Software Dependencies

#### Backend Dependencies

```
fastapi>=0.68.0
uvicorn>=0.15.0
pydantic>=1.8.2
python-multipart>=0.0.5
python-jose[cryptography]>=3.3.0
passlib[bcrypt]>=1.7.4
cryptography>=36.0.0
aiohttp>=3.8.1
```

#### Frontend Dependencies

```
react>=17.0.2
react-dom>=17.0.2
@mui/material>=5.0.0
@emotion/react>=11.0.0
@emotion/styled>=11.0.0
axios>=0.24.0
```

### Network Requirements

- **Ports**: 8000 (API), 3000 (Development frontend), 80/443 (Production)
- **Firewall Rules**: Allow inbound HTTP/HTTPS traffic
- **Domain**: Configure DNS for production deployment
- **SSL Certificate**: Required for production deployment

## Configuration Management

### Environment Variables

Store sensitive configuration in environment variables:

```bash
# API Key Manager Configuration
API_KEY_SECRET=your-secure-secret-key
API_KEYS_PATH=/path/to/api_keys.json

# Authentication Configuration
JWT_SECRET_KEY=your-jwt-secret-key
JWT_ALGORITHM=HS256
JWT_EXPIRATION_MINUTES=60

# Server Configuration
HOST=0.0.0.0
PORT=8000
DEBUG=false
```

### Configuration Files

Use configuration files for non-sensitive settings:

```python
# config.py
from pydantic import BaseSettings
import os

class Settings(BaseSettings):
    # API Key Manager
    api_key_secret: str = os.getenv("API_KEY_SECRET", "")
    api_keys_path: str = os.getenv("API_KEYS_PATH", "api_keys.json")
    
    # Authentication
    jwt_secret_key: str = os.getenv("JWT_SECRET_KEY", "")
    jwt_algorithm: str = os.getenv("JWT_ALGORITHM", "HS256")
    jwt_expiration_minutes: int = int(os.getenv("JWT_EXPIRATION_MINUTES", "60"))
    
    # Server
    host: str = os.getenv("HOST", "0.0.0.0")
    port: int = int(os.getenv("PORT", "8000"))
    debug: bool = os.getenv("DEBUG", "false").lower() == "true"
    
    class Config:
        env_file = ".env"

settings = Settings()
```

### Secret Management

For production, use a secure secret management solution:

- **AWS**: AWS Secrets Manager
- **GCP**: Google Secret Manager
- **Azure**: Azure Key Vault
- **Self-hosted**: HashiCorp Vault

Example with AWS Secrets Manager:

```python
import boto3
import json
import base64
from botocore.exceptions import ClientError

def get_secret(secret_name, region_name="us-east-1"):
    """Get a secret from AWS Secrets Manager."""
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e
    else:
        if 'SecretString' in get_secret_value_response:
            return json.loads(get_secret_value_response['SecretString'])
        else:
            return json.loads(base64.b64decode(get_secret_value_response['SecretBinary']))
```

## Security Considerations

### API Key Encryption

The API Key Manager uses Fernet symmetric encryption to protect API keys at rest:

1. **Secret Key Management**:
   - Store the encryption secret key in a secure environment variable
   - Use a key management service for production
   - Rotate the key periodically (e.g., every 90 days)

2. **Salt Management**:
   - Store the salt securely, not hardcoded in the source code
   - Use a different salt for each deployment environment

3. **File Permissions**:
   - Restrict access to the encrypted API keys file
   - Set file permissions to 600 (owner read/write only)
   - Store the file in a secure location outside the web root

### Authentication and Authorization

Implement proper authentication and authorization:

1. **JWT Authentication**:
   - Use short-lived JWT tokens (60 minutes or less)
   - Implement token refresh mechanism
   - Store the JWT secret key securely

2. **Role-Based Access Control**:
   - Restrict API settings access to administrators only
   - Implement proper role checks in API endpoints
   - Use middleware for consistent authorization

3. **Password Security**:
   - Use strong password hashing (bcrypt)
   - Implement password complexity requirements
   - Enforce multi-factor authentication for admin access

### Network Security

Secure the network communication:

1. **HTTPS**:
   - Use HTTPS for all communication
   - Configure proper SSL/TLS settings
   - Use modern TLS versions (TLS 1.2+)
   - Implement HTTP Strict Transport Security (HSTS)

2. **API Security**:
   - Implement rate limiting
   - Use proper CORS configuration
   - Add security headers (X-Content-Type-Options, X-Frame-Options, etc.)

3. **Firewall Configuration**:
   - Restrict access to necessary ports only
   - Implement IP-based access controls for admin endpoints
   - Use a Web Application Firewall (WAF) for production

### Audit Logging

Implement comprehensive audit logging:

1. **Authentication Events**:
   - Log all login attempts (successful and failed)
   - Log token issuance and refresh
   - Log logout events

2. **API Key Management**:
   - Log all API key operations (create, update, delete)
   - Log API key usage
   - Log validation attempts

3. **Log Security**:
   - Protect log files from unauthorized access
   - Implement log rotation
   - Consider using a centralized logging solution

## Deployment Process

### Backend Deployment

#### Docker Deployment

Create a Dockerfile for the backend:

```dockerfile
FROM python:3.9-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY src/ /app/src/

# Set environment variables
ENV PYTHONPATH=/app
ENV API_KEYS_PATH=/data/api_keys.json

# Create data directory
RUN mkdir -p /data && chmod 700 /data

# Run the application
CMD ["uvicorn", "src.api.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

Create a docker-compose.yml file:

```yaml
version: '3'

services:
  api:
    build: .
    ports:
      - "8000:8000"
    volumes:
      - api_data:/data
    env_file:
      - .env.production
    restart: unless-stopped

volumes:
  api_data:
```

#### Kubernetes Deployment

Create Kubernetes deployment files:

```yaml
# api-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-key-manager
  labels:
    app: api-key-manager
spec:
  replicas: 2
  selector:
    matchLabels:
      app: api-key-manager
  template:
    metadata:
      labels:
        app: api-key-manager
    spec:
      containers:
      - name: api
        image: your-registry/api-key-manager:latest
        ports:
        - containerPort: 8000
        env:
        - name: API_KEY_SECRET
          valueFrom:
            secretKeyRef:
              name: api-key-manager-secrets
              key: api-key-secret
        - name: JWT_SECRET_KEY
          valueFrom:
            secretKeyRef:
              name: api-key-manager-secrets
              key: jwt-secret-key
        volumeMounts:
        - name: api-data
          mountPath: /data
      volumes:
      - name: api-data
        persistentVolumeClaim:
          claimName: api-data-pvc
```

```yaml
# api-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: api-key-manager
spec:
  selector:
    app: api-key-manager
  ports:
  - port: 80
    targetPort: 8000
  type: ClusterIP
```

```yaml
# api-ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: api-key-manager
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
spec:
  rules:
  - host: api.yourdomain.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: api-key-manager
            port:
              number: 80
  tls:
  - hosts:
    - api.yourdomain.com
    secretName: api-tls-cert
```

### Frontend Deployment

#### Build Process

Create a production build of the frontend:

```bash
# Install dependencies
npm install

# Build for production
npm run build
```

#### Nginx Configuration

Create an Nginx configuration for serving the frontend:

```nginx
server {
    listen 80;
    server_name admin.yourdomain.com;
    
    # Redirect HTTP to HTTPS
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name admin.yourdomain.com;
    
    # SSL configuration
    ssl_certificate /etc/letsencrypt/live/admin.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/admin.yourdomain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;
    
    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options DENY;
    add_header X-XSS-Protection "1; mode=block";
    add_header Content-Security-Policy "default-src 'self'; script-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; font-src 'self'; connect-src 'self' https://api.yourdomain.com;";
    
    # Root directory
    root /var/www/admin;
    index index.html;
    
    # Static files
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # API proxy
    location /api/ {
        proxy_pass https://api.yourdomain.com/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Deployment Automation

Use CI/CD pipelines for automated deployment:

#### GitHub Actions

```yaml
# .github/workflows/deploy.yml
name: Deploy

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: 3.9
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    
    - name: Run tests
      run: |
        pytest
    
    - name: Build and push Docker image
      uses: docker/build-push-action@v2
      with:
        context: .
        push: true
        tags: your-registry/api-key-manager:latest
    
    - name: Deploy to Kubernetes
      uses: steebchen/kubectl@v2
      with:
        config: ${{ secrets.KUBE_CONFIG_DATA }}
        command: apply -f k8s/
```

## Monitoring and Logging

### Application Logging

Implement comprehensive application logging:

```python
# src/common/logging.py
import logging
import os
import json
from datetime import datetime

class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging."""
    
    def format(self, record):
        log_record = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno
        }
        
        if hasattr(record, 'request_id'):
            log_record["request_id"] = record.request_id
        
        if record.exc_info:
            log_record["exception"] = self.formatException(record.exc_info)
        
        return json.dumps(log_record)

def setup_logging(log_level=logging.INFO, log_file=None):
    """Set up logging configuration."""
    # Create logger
    logger = logging.getLogger()
    logger.setLevel(log_level)
    
    # Remove existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # Create console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(JSONFormatter())
    logger.addHandler(console_handler)
    
    # Create file handler if log file is specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(JSONFormatter())
        logger.addHandler(file_handler)
    
    return logger
```

### API Key Usage Monitoring

Monitor API key usage and validation:

```python
# src/common/security/api_key_usage.py
import time
import logging
from datetime import datetime
from typing import Dict, Any, Optional

class APIKeyUsageMonitor:
    """Monitor API key usage."""
    
    def __init__(self):
        """Initialize the API key usage monitor."""
        self.logger = logging.getLogger("api_key_usage")
        self.usage = {}
    
    def record_usage(self, service: str, key_name: str, success: bool, response_time: float = None):
        """Record API key usage."""
        # Initialize service if not exists
        if service not in self.usage:
            self.usage[service] = {}
        
        # Initialize key if not exists
        if key_name not in self.usage[service]:
            self.usage[service][key_name] = {
                "total_requests": 0,
                "successful_requests": 0,
                "failed_requests": 0,
                "last_used": None,
                "average_response_time": None
            }
        
        # Update usage statistics
        self.usage[service][key_name]["total_requests"] += 1
        if success:
            self.usage[service][key_name]["successful_requests"] += 1
        else:
            self.usage[service][key_name]["failed_requests"] += 1
        
        self.usage[service][key_name]["last_used"] = datetime.utcnow().isoformat()
        
        # Update response time if provided
        if response_time is not None:
            current_avg = self.usage[service][key_name].get("average_response_time")
            if current_avg is None:
                self.usage[service][key_name]["average_response_time"] = response_time
            else:
                # Weighted average (90% old, 10% new)
                self.usage[service][key_name]["average_response_time"] = (
                    current_avg * 0.9 + response_time * 0.1
                )
        
        # Log the usage
        self.logger.info(
            f"API key usage: service={service}, key={key_name}, success={success}",
            extra={
                "service": service,
                "key_name": key_name,
                "success": success,
                "response_time": response_time
            }
        )
    
    def get_usage_statistics(self, service: Optional[str] = None, key_name: Optional[str] = None) -> Dict[str, Any]:
        """Get usage statistics."""
        if service and key_name:
            return self.usage.get(service, {}).get(key_name, {})
        elif service:
            return self.usage.get(service, {})
        else:
            return self.usage
```

### Health Checks

Implement health check endpoints:

```python
# src/api/routes/health.py
from fastapi import APIRouter, Depends
from typing import Dict, Any
import os
import psutil

router = APIRouter(prefix="/health", tags=["health"])

@router.get("/liveness")
async def liveness_check() -> Dict[str, Any]:
    """Check if the application is alive."""
    return {"status": "ok"}

@router.get("/readiness")
async def readiness_check() -> Dict[str, Any]:
    """Check if the application is ready to serve requests."""
    # Check if API key file is accessible
    api_keys_path = os.getenv("API_KEYS_PATH", "api_keys.json")
    api_keys_accessible = os.path.exists(api_keys_path) and os.access(api_keys_path, os.R_OK | os.W_OK)
    
    return {
        "status": "ok" if api_keys_accessible else "not_ready",
        "api_keys_accessible": api_keys_accessible
    }

@router.get("/metrics")
async def metrics() -> Dict[str, Any]:
    """Get application metrics."""
    process = psutil.Process(os.getpid())
    
    return {
        "memory_usage": process.memory_info().rss,
        "cpu_percent": process.cpu_percent(),
        "open_files": len(process.open_files()),
        "connections": len(process.connections()),
        "threads": process.num_threads()
    }
```

### Prometheus Integration

Add Prometheus metrics:

```python
# src/api/metrics.py
from prometheus_client import Counter, Histogram, Gauge
import time

# API key operations
api_key_operations = Counter(
    'api_key_operations_total',
    'Total number of API key operations',
    ['operation', 'service']
)

# API key validation
api_key_validations = Counter(
    'api_key_validations_total',
    'Total number of API key validations',
    ['service', 'success']
)

# API request duration
api_request_duration = Histogram(
    'api_request_duration_seconds',
    'API request duration in seconds',
    ['endpoint']
)

# API key count
api_key_count = Gauge(
    'api_key_count',
    'Number of API keys',
    ['service']
)

class PrometheusMiddleware:
    """Middleware for Prometheus metrics."""
    
    async def __call__(self, request, call_next):
        start_time = time.time()
        
        response = await call_next(request)
        
        # Record request duration
        duration = time.time() - start_time
        endpoint = f"{request.method} {request.url.path}"
        api_request_duration.labels(endpoint=endpoint).observe(duration)
        
        return response
```

### Grafana Dashboard

Create a Grafana dashboard for monitoring:

```json
{
  "annotations": {
    "list": [
      {
        "builtIn": 1,
        "datasource": "-- Grafana --",
        "enable": true,
        "hide": true,
        "iconColor": "rgba(0, 211, 255, 1)",
        "name": "Annotations & Alerts",
        "type": "dashboard"
      }
    ]
  },
  "editable": true,
  "gnetId": null,
  "graphTooltip": 0,
  "id": 1,
  "links": [],
  "panels": [
    {
      "aliasColors": {},
      "bars": false,
      "dashLength": 10,
      "dashes": false,
      "datasource": null,
      "fieldConfig": {
        "defaults": {},
        "overrides": []
      },
      "fill": 1,
      "fillGradient": 0,
      "gridPos": {
        "h": 8,
        "w": 12,
        "x": 0,
        "y": 0
      },
      "hiddenSeries": false,
      "id": 2,
      "legend": {
        "avg": false,
        "current": false,
        "max": false,
        "min": false,
        "show": true,
        "total": false,
        "values": false
      },
      "lines": true,
      "linewidth": 1,
      "nullPointMode": "null",
      "options": {
        "alertThreshold": true
      },
      "percentage": false,
      "pluginVersion": "7.5.5",
      "pointradius": 2,
      "points": false,
      "renderer": "flot",
      "seriesOverrides": [],
      "spaceLength": 10,
      "stack": false,
      "steppedLine": false,
      "targets": [
        {
          "exemplar": true,
          "expr": "sum(rate(api_key_operations_total[5m])) by (operation)",
          "interval": "",
          "legendFormat": "{{operation}}",
          "refId": "A"
        }
      ],
      "thresholds": [],
      "timeFrom": null,
      "timeRegions": [],
      "timeShift": null,
      "title": "API Key Operations",
      "tooltip": {
        "shared": true,
        "sort": 0,
        "value_type": "individual"
      },
      "type": "graph",
      "xaxis": {
        "buckets": null,
        "mode": "time",
        "name": null,
        "show": true,
        "values": []
      },
      "yaxes": [
        {
          "format": "short",
          "label": null,
          "logBase": 1,
          "max": null,
          "min": null,
          "show": true
        },
        {
          "format": "short",
          "label": null,
          "logBase": 1,
          "max": null,
          "min": null,
          "show": true
        }
      ],
      "yaxis": {
        "align": false,
        "alignLevel": null
      }
    },
    {
      "aliasColors": {},
      "bars": false,
      "dashLength": 10,
      "dashes": false,
      "datasource": null,
      "fieldConfig": {
        "defaults": {},
        "overrides": []
      },
      "fill": 1,
      "fillGradient": 0,
      "gridPos": {
        "h": 8,
        "w": 12,
        "x": 12,
        "y": 0
      },
      "hiddenSeries": false,
      "id": 4,
      "legend": {
        "avg": false,
        "current": false,
        "max": false,
        "min": false,
        "show": true,
        "total": false,
        "values": false
      },
      "lines": true,
      "linewidth": 1,
      "nullPointMode": "null",
      "options": {
        "alertThreshold": true
      },
      "percentage": false,
      "pluginVersion": "7.5.5",
      "pointradius": 2,
      "points": false,
      "renderer": "flot",
      "seriesOverrides": [],
      "spaceLength": 10,
      "stack": false,
      "steppedLine": false,
      "targets": [
        {
          "exemplar": true,
          "expr": "sum(rate(api_key_validations_total[5m])) by (service, success)",
          "interval": "",
          "legendFormat": "{{service}} - {{success}}",
          "refId": "A"
        }
      ],
      "thresholds": [],
      "timeFrom": null,
      "timeRegions": [],
      "timeShift": null,
      "title": "API Key Validations",
      "tooltip": {
        "shared": true,
        "sort": 0,
        "value_type": "individual"
      },
      "type": "graph",
      "xaxis": {
        "buckets": null,
        "mode": "time",
        "name": null,
        "show": true,
        "values": []
      },
      "yaxes": [
        {
          "format": "short",
          "label": null,
          "logBase": 1,
          "max": null,
          "min": null,
          "show": true
        },
        {
          "format": "short",
          "label": null,
          "logBase": 1,
          "max": null,
          "min": null,
          "show": true
        }
      ],
      "yaxis": {
        "align": false,
        "alignLevel": null
      }
    },
    {
      "aliasColors": {},
      "bars": false,
      "dashLength": 10,
      "dashes": false,
      "datasource": null,
      "fieldConfig": {
        "defaults": {},
        "overrides": []
      },
      "fill": 1,
      "fillGradient": 0,
      "gridPos": {
        "h": 8,
        "w": 12,
        "x": 0,
        "y": 8
      },
      "hiddenSeries": false,
      "id": 6,
      "legend": {
        "avg": false,
        "current": false,
        "max": false,
        "min": false,
        "show": true,
        "total": false,
        "values": false
      },
      "lines": true,
      "linewidth": 1,
      "nullPointMode": "null",
      "options": {
        "alertThreshold": true
      },
      "percentage": false,
      "pluginVersion": "7.5.5",
      "pointradius": 2,
      "points": false,
      "renderer": "flot",
      "seriesOverrides": [],
      "spaceLength": 10,
      "stack": false,
      "steppedLine": false,
      "targets": [
        {
          "exemplar": true,
          "expr": "histogram_quantile(0.95, sum(rate(api_request_duration_seconds_bucket[5m])) by (endpoint, le))",
          "interval": "",
          "legendFormat": "{{endpoint}}",
          "refId": "A"
        }
      ],
      "thresholds": [],
      "timeFrom": null,
      "timeRegions": [],
      "timeShift": null,
      "title": "API Request Duration (95th percentile)",
      "tooltip": {
        "shared": true,
        "sort": 0,
        "value_type": "individual"
      },
      "type": "graph",
      "xaxis": {
        "buckets": null,
        "mode": "time",
        "name": null,
        "show": true,
        "values": []
      },
      "yaxes": [
        {
          "format": "s",
          "label": null,
          "logBase": 1,
          "max": null,
          "min": null,
          "show": true
        },
        {
          "format": "short",
          "label": null,
          "logBase": 1,
          "max": null,
          "min": null,
          "show": true
        }
      ],
      "yaxis": {
        "align": false,
        "alignLevel": null
      }
    },
    {
      "datasource": null,
      "fieldConfig": {
        "defaults": {
          "color": {
            "mode": "thresholds"
          },
          "mappings": [],
          "thresholds": {
            "mode": "absolute",
            "steps": [
              {
                "color": "green",
                "value": null
              },
              {
                "color": "red",
                "value": 80
              }
            ]
          }
        },
        "overrides": []
      },
      "gridPos": {
        "h": 8,
        "w": 12,
        "x": 12,
        "y": 8
      },
      "id": 8,
      "options": {
        "displayMode": "gradient",
        "orientation": "auto",
        "reduceOptions": {
          "calcs": [
            "lastNotNull"
          ],
          "fields": "",
          "values": false
        },
        "showUnfilled": true,
        "text": {}
      },
      "pluginVersion": "7.5.5",
      "targets": [
        {
          "exemplar": true,
          "expr": "api_key_count",
          "interval": "",
          "legendFormat": "{{service}}",
          "refId": "A"
        }
      ],
      "title": "API Key Count",
      "type": "bargauge"
    }
  ],
  "refresh": "10s",
  "schemaVersion": 27,
  "style": "dark",
  "tags": [],
  "templating": {
    "list": []
  },
  "time": {
    "from": "now-6h",
    "to": "now"
  },
  "timepicker": {},
  "timezone": "",
  "title": "API Key Management",
  "uid": "api-key-management",
  "version": 1
}
```

## Backup and Recovery

### Backup Strategy

Implement a regular backup strategy:

```python
# src/scripts/backup_api_keys.py
import os
import shutil
import datetime
import argparse
import logging

def backup_api_keys(api_keys_path, backup_dir):
    """Backup API keys file."""
    # Create backup directory if it doesn't exist
    os.makedirs(backup_dir, exist_ok=True)
    
    # Check if API keys file exists
    if not os.path.exists(api_keys_path):
        logging.error(f"API keys file not found: {api_keys_path}")
        return False
    
    # Create backup filename with timestamp
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_filename = f"api_keys_{timestamp}.json"
    backup_path = os.path.join(backup_dir, backup_filename)
    
    # Copy the file
    try:
        shutil.copy2(api_keys_path, backup_path)
        logging.info(f"Backup created: {backup_path}")
        
        # Set proper permissions
        os.chmod(backup_path, 0o600)
        
        return True
    except Exception as e:
        logging.error(f"Backup failed: {e}")
        return False

def cleanup_old_backups(backup_dir, max_backups=10):
    """Clean up old backups, keeping only the most recent ones."""
    # List all backup files
    backup_files = []
    for filename in os.listdir(backup_dir):
        if filename.startswith("api_keys_") and filename.endswith(".json"):
            backup_path = os.path.join(backup_dir, filename)
            backup_files.append((backup_path, os.path.getmtime(backup_path)))
    
    # Sort by modification time (newest first)
    backup_files.sort(key=lambda x: x[1], reverse=True)
    
    # Delete old backups
    if len(backup_files) > max_backups:
        for backup_path, _ in backup_files[max_backups:]:
            try:
                os.remove(backup_path)
                logging.info(f"Deleted old backup: {backup_path}")
            except Exception as e:
                logging.error(f"Failed to delete old backup: {e}")

if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )
    
    # Parse arguments
    parser = argparse.ArgumentParser(description="Backup API keys file")
    parser.add_argument("--api-keys-path", default=os.getenv("API_KEYS_PATH", "api_keys.json"))
    parser.add_argument("--backup-dir", default="backups")
    parser.add_argument("--max-backups", type=int, default=10)
    args = parser.parse_args()
    
    # Backup API keys
    if backup_api_keys(args.api_keys_path, args.backup_dir):
        # Clean up old backups
        cleanup_old_backups(args.backup_dir, args.max_backups)
```

### Cron Job

Set up a cron job for regular backups:

```bash
# /etc/cron.d/api-key-backups
0 * * * * root /app/venv/bin/python /app/src/scripts/backup_api_keys.py --api-keys-path=/data/api_keys.json --backup-dir=/backups
```

### Recovery Procedure

Document the recovery procedure:

1. **Identify the Backup**:
   - List available backups: `ls -la /backups`
   - Choose the most recent valid backup

2. **Restore the Backup**:
   - Stop the API service: `systemctl stop api-key-manager`
   - Copy the backup: `cp /backups/api_keys_TIMESTAMP.json /data/api_keys.json`
   - Set proper permissions: `chmod 600 /data/api_keys.json`
   - Start the API service: `systemctl start api-key-manager`

3. **Verify the Restoration**:
   - Check the API service status: `systemctl status api-key-manager`
   - Test API key retrieval: `curl -H "Authorization: Bearer TOKEN" https://api.yourdomain.com/api/settings/services`

## Scaling Considerations

### Horizontal Scaling

For horizontal scaling, consider these approaches:

1. **Shared Storage**:
   - Use a shared file system (NFS, EFS) for the API keys file
   - Implement proper file locking for concurrent access

2. **Database Storage**:
   - Migrate from file-based storage to a database
   - Use a database with good encryption support (PostgreSQL)

3. **Distributed Cache**:
   - Use a distributed cache (Redis) for frequently accessed keys
   - Implement cache invalidation on key updates

### Database Migration

Example schema for database storage:

```sql
-- Create API keys table
CREATE TABLE api_keys (
    id SERIAL PRIMARY KEY,
    service VARCHAR(255) NOT NULL,
    key_name VARCHAR(255) NOT NULL,
    key_value TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (service, key_name)
);

-- Create metadata table
CREATE TABLE api_key_metadata (
    id SERIAL PRIMARY KEY,
    service VARCHAR(255) NOT NULL,
    last_updated TIMESTAMP NOT NULL DEFAULT NOW(),
    last_validated TIMESTAMP,
    UNIQUE (service)
);

-- Create audit log table
CREATE TABLE api_key_audit_log (
    id SERIAL PRIMARY KEY,
    action VARCHAR(50) NOT NULL,
    service VARCHAR(255) NOT NULL,
    key_name VARCHAR(255),
    user_id VARCHAR(255) NOT NULL,
    timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
    details JSONB
);
```

## Maintenance Procedures

### Key Rotation

Implement a key rotation procedure:

```python
# src/scripts/rotate_encryption_key.py
import os
import json
import base64
import argparse
import logging
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

def derive_key(secret_key, salt):
    """Derive a key from a secret key and salt."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    return base64.urlsafe_b64encode(kdf.derive(secret_key.encode()))

def rotate_encryption_key(api_keys_path, old_secret_key, new_secret_key, old_salt=b'api-key-manager-salt', new_salt=b'api-key-manager-salt-new'):
    """Rotate the encryption key for API keys."""
    # Check if API keys file exists
    if not os.path.exists(api_keys_path):
        logging.error(f"API keys file not found: {api_keys_path}")
        return False
    
    try:
        # Derive old key
        old_key = derive_key(old_secret_key, old_salt)
        old_cipher = Fernet(old_key)
        
        # Derive new key
        new_key = derive_key(new_secret_key, new_salt)
        new_cipher = Fernet(new_key)
        
        # Read encrypted data
        with open(api_keys_path, 'r') as f:
            encrypted_data = f.read()
        
        # Decrypt with old key
        decrypted_data = old_cipher.decrypt(encrypted_data.encode()).decode()
        api_keys = json.loads(decrypted_data)
        
        # Encrypt with new key
        new_encrypted_data = new_cipher.encrypt(json.dumps(api_keys).encode()).decode()
        
        # Write back to file
        with open(api_keys_path, 'w') as f:
            f.write(new_encrypted_data)
        
        # Set proper permissions
        os.chmod(api_keys_path, 0o600)
        
        logging.info(f"Encryption key rotated successfully for {api_keys_path}")
        return True
    except Exception as e:
        logging.error(f"Key rotation failed: {e}")
        return False

if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )
    
    # Parse arguments
    parser = argparse.ArgumentParser(description="Rotate encryption key for API keys")
    parser.add_argument("--api-keys-path", default=os.getenv("API_KEYS_PATH", "api_keys.json"))
    parser.add_argument("--old-secret-key", required=True)
    parser.add_argument("--new-secret-key", required=True)
    args = parser.parse_args()
    
    # Rotate encryption key
    rotate_encryption_key(args.api_keys_path, args.old_secret_key, args.new_secret_key)
```

### Health Check

Create a health check script:

```python
# src/scripts/health_check.py
import os
import json
import requests
import argparse
import logging
import sys

def check_api_health(api_url, token=None):
    """Check the health of the API."""
    # Set up headers
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    
    try:
        # Check liveness
        liveness_url = f"{api_url}/health/liveness"
        liveness_response = requests.get(liveness_url, headers=headers, timeout=5)
        liveness_ok = liveness_response.status_code == 200
        
        # Check readiness
        readiness_url = f"{api_url}/health/readiness"
        readiness_response = requests.get(readiness_url, headers=headers, timeout=5)
        readiness_ok = readiness_response.status_code == 200
        
        # Check metrics
        metrics_url = f"{api_url}/health/metrics"
        metrics_response = requests.get(metrics_url, headers=headers, timeout=5)
        metrics_ok = metrics_response.status_code == 200
        
        # Check API settings
        settings_url = f"{api_url}/api/settings/services"
        settings_response = requests.get(settings_url, headers=headers, timeout=5)
        settings_ok = settings_response.status_code == 200
        
        # Print results
        logging.info(f"Liveness: {'OK' if liveness_ok else 'FAIL'}")
        logging.info(f"Readiness: {'OK' if readiness_ok else 'FAIL'}")
        logging.info(f"Metrics: {'OK' if metrics_ok else 'FAIL'}")
        logging.info(f"API Settings: {'OK' if settings_ok else 'FAIL'}")
        
        # Return overall status
        return liveness_ok and readiness_ok and metrics_ok and settings_ok
    except Exception as e:
        logging.error(f"Health check failed: {e}")
        return False

if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )
    
    # Parse arguments
    parser = argparse.ArgumentParser(description="Check API health")
    parser.add_argument("--api-url", default="http://localhost:8000")
    parser.add_argument("--token")
    args = parser.parse_args()
    
    # Check API health
    if not check_api_health(args.api_url, args.token):
        sys.exit(1)
```

### Log Rotation

Configure log rotation:

```
# /etc/logrotate.d/api-key-manager
/var/log/api-key-manager/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    create 0640 root root
    sharedscripts
    postrotate
        systemctl reload api-key-manager
    endscript
}
```

## Troubleshooting

### Common Issues

1. **API Keys Not Loading**:
   - Check file permissions: `ls -la /data/api_keys.json`
   - Verify encryption key: Check environment variable `API_KEY_SECRET`
   - Check logs for decryption errors

2. **Authentication Failures**:
   - Verify JWT token expiration
   - Check user roles and permissions
   - Verify JWT secret key

3. **Performance Issues**:
   - Check system resources (CPU, memory)
   - Monitor API response times
   - Check for excessive API key validations

### Debugging

Enable debug logging:

```bash
# Set environment variable
export DEBUG=true

# Restart the service
systemctl restart api-key-manager
```

### Support Information

Provide support contact information:

- **Email**: support@yourdomain.com
- **Internal Ticket System**: https://support.internal.yourdomain.com
- **Documentation**: https://docs.yourdomain.com/api-key-manager

## Conclusion

This deployment guide provides comprehensive instructions for deploying, configuring, monitoring, and maintaining the API Key Management System. By following these recommendations, you can ensure a secure, reliable, and scalable deployment that meets the needs of your AI Trading Agent project.

The system is designed with security in mind, using encryption for API keys at rest and proper authentication for the admin interface. It also includes monitoring and logging capabilities to help you track usage and troubleshoot issues.

For any questions or issues, please refer to the troubleshooting section or contact the support team.
